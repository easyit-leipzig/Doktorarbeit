-- ============================================================
-- FRZK-RKB: Abschnittsabschluss-Template
-- Für jeden neuen fertiggestellten Dissertationsteil kopieren.
-- ============================================================

USE frzk_rkb;
SET NAMES utf8mb4;
START TRANSACTION;

-- 1. Revision registrieren
INSERT INTO repository_revisions
(revision_code,revision_date,scope_type,scope_reference,version_label,summary)
VALUES
('RKB-YYYY-MM-DD-SECTION','YYYY-MM-DD HH:MM:SS','section','3.x.x','1.0',
 'Fertigstellung von Abschnitt 3.x.x.');

SET @revision_id = LAST_INSERT_ID();
SET @section_id = (SELECT section_id FROM dissertation_sections WHERE section_code='3.x.x');

-- 2. Neue Quelle nur dann anlegen, wenn sie noch nicht existiert
INSERT INTO sources
(citation_number,source_key,source_type,title,year_original,journal,publisher,place,pages,
 language_code,priority,evidence_type,frzk_relevance,verification_status,
 first_citation_section_code,full_citation_text,short_citation_text)
SELECT
  23,'autor_kurztitel_jahr','journal_article','Titel',1900,'Journal',NULL,NULL,'1–10',
  'de',5,'primary',3,'needs_review','3.x.x',
  'Vollständige Quellenbeschreibung [23].','Autor [23]'
WHERE NOT EXISTS (
    SELECT 1 FROM sources WHERE source_key='autor_kurztitel_jahr'
);

-- 3. Annotation zur neuen Quelle
INSERT INTO annotations
(source_id,contribution,significance_for_dissertation,citation_reason,adopted_claims,
 limitations,scientific_discussion,annotation_status)
SELECT
  s.source_id,
  'Wissenschaftlicher Beitrag.',
  'Bedeutung für die Dissertation.',
  'Warum die Quelle zitiert wird.',
  'Übernommene Aussagen.',
  'Grenzen.',
  'Bezug zu anderer Forschung.',
  'draft'
FROM sources s
WHERE s.source_key='autor_kurztitel_jahr'
AND NOT EXISTS (SELECT 1 FROM annotations a WHERE a.source_id=s.source_id);

-- 4. Jede tatsächliche Verwendung dokumentieren
INSERT INTO source_usage
(source_id,section_id,usage_type,claim_summary,exact_location,is_first_mention,citation_checked)
VALUES
((SELECT source_id FROM sources WHERE source_key='autor_kurztitel_jahr'),
 @section_id,'first_citation','Belegte Aussage.','Absatz 1',TRUE,FALSE);

-- 5. Bestehende Quelle wiederverwenden: kein neues sources-INSERT
INSERT INTO source_usage
(source_id,section_id,usage_type,claim_summary,exact_location,is_first_mention,citation_checked)
VALUES
((SELECT source_id FROM sources WHERE citation_number=8),
 @section_id,'background','Wiederverwendung von Hilbert [8].','Absatz 2',FALSE,TRUE);

-- 6. Gleichung registrieren
INSERT INTO equations
(equation_number,section_id,title,equation_latex,word_latex,plain_description,
 equation_type,provenance,source_id,validation_status)
VALUES
('3.3',@section_id,'Titel der Gleichung',
 'f:A\\rightarrow B',
 'f:A\\rightarrow B',
 'Inhaltliche Bedeutung der Gleichung.',
 'definition','literature',
 (SELECT source_id FROM sources WHERE source_key='autor_kurztitel_jahr'),
 'draft');

SET @equation_id = LAST_INSERT_ID();

-- 7. Gleichungssymbole registrieren
INSERT INTO equation_symbols
(equation_id,symbol_latex,symbol_name,definition_text,domain_text,symbol_order)
VALUES
(@equation_id,'f','Funktion','Eindeutige Abbildung zwischen zwei Mengen.','A\\rightarrow B',1);

-- 8. Globales Symbolverzeichnis ergänzen
INSERT INTO symbols
(symbol_latex,symbol_word_latex,symbol_name,definition_text,scope_type,first_section_id,
 first_equation_id,is_operator,validation_status,created_revision_id)
VALUES
('f','f','Funktion','Eindeutige Abbildung zwischen Definitions- und Zielmenge.',
 'section',@section_id,@equation_id,FALSE,'draft',@revision_id);

-- 9. Definition registrieren
INSERT INTO definitions
(definition_number,section_id,title,definition_text,formal_latex,word_latex,
 provenance,source_id,validation_status,created_revision_id)
VALUES
('Def. 3.2.1',@section_id,'Funktion',
 'Eine Funktion ordnet jedem Element der Definitionsmenge genau ein Element der Zielmenge zu.',
 'f:A\\rightarrow B','f:A\\rightarrow B',
 'literature',(SELECT source_id FROM sources WHERE source_key='autor_kurztitel_jahr'),
 'draft',@revision_id);

-- 10. Satz registrieren
INSERT INTO theorems
(theorem_number,section_id,title,statement_text,statement_latex,word_latex,proof_text,
 provenance,source_id,validation_status,created_revision_id)
VALUES
('Satz 3.2.1',@section_id,'Beispielsatz',
 'Aussage des Satzes.','A=B','A=B','Beweistext.',
 'literature',(SELECT source_id FROM sources WHERE source_key='autor_kurztitel_jahr'),
 'draft',@revision_id);

-- 11. Abbildung registrieren
INSERT INTO figures
(figure_number,section_id,title,caption,file_name,file_path,figure_type,provenance,
 source_id,generation_method,validation_status,created_revision_id)
VALUES
('Abb. 3.1',@section_id,'Titel','Vollständige Bildunterschrift.',
 'abb_3_1.png','/pfad/abb_3_1.png','diagram','original',
 NULL,'Python/Matplotlib','draft',@revision_id);

-- 12. Tabelle registrieren
INSERT INTO dissertation_tables
(table_number,section_id,title,caption,table_schema_json,table_data_json,
 provenance,validation_status,created_revision_id)
VALUES
('Tab. 3.1',@section_id,'Titel','Vollständige Tabellenbeschriftung.',
 JSON_OBJECT('columns',JSON_ARRAY('Spalte 1','Spalte 2')),
 JSON_ARRAY(JSON_OBJECT('Spalte 1','Wert A','Spalte 2','Wert B')),
 'original','draft',@revision_id);

-- 13. Abkürzung registrieren
INSERT INTO acronyms
(acronym,full_form,explanation,first_section_id,category,is_project_specific,
 validation_status,created_revision_id)
VALUES
('ABC','Ausgeschriebene Bezeichnung','Erläuterung.',@section_id,'Mathematik',FALSE,'draft',@revision_id)
ON DUPLICATE KEY UPDATE explanation=VALUES(explanation);

-- 14. Änderungsprotokoll
INSERT INTO section_change_log
(revision_id,section_id,change_type,object_type,object_reference,change_summary)
VALUES
(@revision_id,@section_id,'source_added','source','[23]','Neue Quelle aufgenommen.'),
(@revision_id,@section_id,'equation_added','equation','(3.3)','Neue Gleichung aufgenommen.'),
(@revision_id,@section_id,'definition_added','definition','Def. 3.2.1','Neue Definition aufgenommen.'),
(@revision_id,@section_id,'statement_added','theorem','Satz 3.2.1','Neuen Satz aufgenommen.');

-- 15. Abschnittsstatus aktualisieren
UPDATE dissertation_sections
SET status='review'
WHERE section_id=@section_id;

COMMIT;
