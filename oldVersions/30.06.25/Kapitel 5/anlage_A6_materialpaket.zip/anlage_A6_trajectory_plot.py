import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
from mpl_toolkits.mplot3d import Axes3D

# Definition der semantischen Operatorwerte über die Zeit
states = np.array([
    [0.3, 0.2, 0.0, 0.1, 0.0, 0.0],  # t0: Ausgangszustand
    [0.3, 0.2, 0.3, 0.1, 0.0, 0.0],  # t1: D ↑
    [0.3, 0.5, 0.3, 0.1, 0.0, 0.0],  # t2: S ↑
    [0.3, 0.5, 0.3, 0.4, 0.0, 0.0],  # t3: M ↑
    [0.3, 0.5, 0.3, 0.4, 0.3, 0.0],  # t4: R ↑
    [0.3, 0.5, 0.3, 0.4, 0.3, 0.6],  # t5: E ↑
])

# Achsenwerte extrahieren
sigma, S, D, M, R, E = states.T

fig = plt.figure(figsize=(12, 10))
ax = fig.add_subplot(111, projection='3d')

# Plot nach E (Farbe), sigma (Größe)
sc = ax.scatter(S, D, M, c=E, cmap='viridis', s=100 + 300 * sigma, edgecolor='k')
ax.plot(S, D, M, color='gray', linestyle='--', alpha=0.5)

ax.set_xlabel('S (Symbolik)')
ax.set_ylabel('D (Diskurs)')
ax.set_zlabel('M (Metareflexion)')
ax.set_title('6D-Trajektorie im intentionalen Raum I(t)')

# Zeitpunkte beschriften
for i, (x, y, z) in enumerate(zip(S, D, M)):
    ax.text(x, y, z, f't{i}', fontsize=9)

# Farbleiste
cbar = plt.colorbar(sc, ax=ax, shrink=0.6, pad=0.1)
cbar.set_label('Emergenz E')

plt.tight_layout()
plt.show()
