# FRZK Research Knowledge Base – Startbestand

Erstellt: 2026-07-11 18:59

## Dateien

- `01_frzk_rkb_schema_mysql.sql` – vollständiges MySQL-8-Schema
- `02_frzk_rkb_seed_chapter_3_1_mysql.sql` – Startdaten aus dem finalen Abschnitt 3.1
- `frzk_rkb_chapter3_1.sqlite` – portable, sofort nutzbare SQLite-Datenbank

## Enthaltener Startbestand

- 22 fest nummerierte Quellen aus Abschnitt 3.1 (`[1]` bis `[22]`)
- 25 Autorendatensätze
- 24 Kapitel- und Unterkapitelstrukturen für 3.1–3.4
- 22 wissenschaftliche Kurzannotationenen
- 12 Themenfelder
- 36 dokumentierte Quellenverwendungen
- 2 Gleichungen aus Abschnitt 3.1: `(3.1)` und `(3.2)`
- 6 exemplarische Beziehungen zwischen Quellen

## Nummerierungsstand

- Nächste freie Literaturstelle: **[23]**
- Nächste freie Gleichungsnummer: **(3.3)**

## Wichtige Designentscheidung

`source_id` ist der dauerhafte technische Primärschlüssel.  
`citation_number` ist die feste, dissertationsweite Literaturnummer.

Dadurch können bibliographische Angaben korrigiert oder ergänzt werden, ohne Beziehungen,
Annotationen oder Verwendungen neu zu verknüpfen.

## MySQL-Import

```bash
mysql -u root < 01_frzk_rkb_schema_mysql.sql
mysql -u root frzk_rkb < 02_frzk_rkb_seed_chapter_3_1_mysql.sql
```

Die Skripte verwenden `utf8mb4` und sind für MySQL 8.0+ ausgelegt.

## Zentrale Tabellen

- `sources` – bibliographische Stammdaten und feste Zitiernummer
- `authors`, `source_authors` – normalisierte Autorenzuordnung
- `annotations` – Beitrag, Bedeutung, Zitiergrund, übernommene Aussagen, Grenzen
- `dissertation_sections` – vollständige Kapitelhierarchie
- `source_usage` – konkrete Verwendung einer Quelle in einem Abschnitt
- `topics`, `source_topics` – fachliche Verschlagwortung
- `source_relations` – wissenschaftliche Beziehungen zwischen Quellen
- `equations`, `equation_symbols` – Gleichungskataster inklusive Word-LaTeX

## Qualitätsstatus

Die 22 bibliographischen Einträge wurden aus der aktuellen finalen DOCX-Fassung von 3.1
übernommen. Sie tragen zunächst den Status `imported`. Vor der endgültigen Einreichung
sollten Auflage, Originaljahr, Seiten, ISBN und DOI anhand von Verlags- oder Primärquellen
einzeln verifiziert werden.
