# FRZK Research Knowledge Base – Dissertations-Repository v2.0

Die Version 2 erweitert die bestehende Literatur- und Gleichungsdatenbank zu einem
vollständigen, reproduzierbaren Dissertations-Repository.

## Neue Tabellen

- `pending_sources` – noch nicht bibliographisch geprüfte Quellen
- `repository_revisions` – versionierte Repository-Revisionen
- `section_change_log` – Änderungsprotokoll je Abschnitt
- `definitions` – Definitionen
- `theorems` – Sätze
- `lemmas` – Lemmata
- `corollaries` – Korollare
- `figures` – Abbildungen
- `dissertation_tables` – Dissertationstabellen
- `symbols` – globales Symbolverzeichnis
- `acronyms` – Abkürzungsverzeichnis
- `equation_dependencies` – Abhängigkeiten zwischen Gleichungen
- `object_source_links` – Quellenbeziehungen zu allen wissenschaftlichen Objekten

## Neue Registeransichten

- `v_definition_register`
- `v_statement_register`
- `v_figure_register`
- `v_table_register`
- `v_symbol_register`
- `v_acronym_register`
- `v_section_inventory`
- `v_pending_source_audit`

## Standardablauf nach jedem Abschnitt

1. Dissertationstext fertigstellen.
2. Revision in `repository_revisions` anlegen.
3. Neue Quellen in `sources` und `annotations` aufnehmen.
4. Bereits vorhandene Quellen nur über `source_usage` wiederverwenden.
5. Gleichungen und Gleichungssymbole registrieren.
6. Definitionen, Sätze, Lemmata und Korollare registrieren.
7. Abbildungen und Tabellen registrieren.
8. Globale Symbole und Abkürzungen ergänzen.
9. Alle Änderungen in `section_change_log` dokumentieren.
10. Abschnittsstatus aktualisieren.

Das vollständige Muster steht in `05_section_completion_template_mysql.sql`.

## Installationsreihenfolge für MySQL

```bash
mysql -u root < 01_frzk_rkb_schema_mysql.sql
mysql -u root frzk_rkb < 02_frzk_rkb_seed_chapter_3_1_mysql.sql
mysql -u root frzk_rkb < 03_frzk_rkb_repository_extension_mysql.sql
mysql -u root frzk_rkb < 04_frzk_rkb_repository_extension_seed_mysql.sql
```

## Portable Datenbank

`frzk_rkb_repository_v2.sqlite` enthält den bisherigen Startbestand sowie die gesamte
Repository-Erweiterung und kann unmittelbar mit SQLite geöffnet werden.
