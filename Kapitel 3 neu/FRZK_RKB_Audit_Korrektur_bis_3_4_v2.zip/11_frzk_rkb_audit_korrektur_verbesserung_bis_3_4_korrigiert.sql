-- ============================================================
-- FRZK-RKB: Audit, Korrektur und Stabilisierung bis Kapitel 3.4
-- Grundlage: frzk_rkb(2).sql
-- Zielsystem: MariaDB 10.4+
-- ============================================================

USE frzk_rkb;
SET NAMES utf8mb4;

-- Die vorherige Fehlermeldung #1109 entstand, wenn information_schema
-- als aktive Datenbank ausgewählt war. Dieses Skript setzt deshalb
-- die Zieldatenbank ausdrücklich.

SET @audit_parent_revision_id := (
    SELECT MAX(rr.revision_id)
    FROM repository_revisions rr
);

INSERT INTO repository_revisions
(revision_code, revision_date, scope_type, scope_reference, version_label,
 summary, created_by, parent_revision_id)
VALUES
('RKB-2026-07-12-AUDIT-K3.4', NOW(), 'repository', 'frzk_rkb', '4.1',
 'Vollständiger Schema-, Daten- und Konsistenzaudit bis einschließlich Kapitel 3.4.',
 'Olaf Thiele / ChatGPT', @audit_parent_revision_id)
ON DUPLICATE KEY UPDATE
 revision_date = VALUES(revision_date),
 version_label = VALUES(version_label),
 summary = VALUES(summary),
 parent_revision_id = VALUES(parent_revision_id);

SET @audit_revision_id := (
    SELECT rr.revision_id
    FROM repository_revisions rr
    WHERE rr.revision_code = 'RKB-2026-07-12-AUDIT-K3.4'
);

-- ------------------------------------------------------------
-- Hilfsprozeduren für idempotente Schemaänderungen
-- ------------------------------------------------------------

DROP PROCEDURE IF EXISTS frzk_add_column_if_missing;
DELIMITER $$
CREATE PROCEDURE frzk_add_column_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_column_name VARCHAR(64),
    IN p_column_definition TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.columns c
        WHERE c.table_schema = DATABASE()
          AND c.table_name = p_table_name
          AND c.column_name = p_column_name
    ) THEN
        SET @sql_stmt = CONCAT(
            'ALTER TABLE `', p_table_name,
            '` ADD COLUMN `', p_column_name, '` ',
            p_column_definition
        );
        PREPARE stmt FROM @sql_stmt;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS frzk_add_index_if_missing;
DELIMITER $$
CREATE PROCEDURE frzk_add_index_if_missing(
    IN p_table_name VARCHAR(64),
    IN p_index_name VARCHAR(64),
    IN p_index_definition TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.statistics s
        WHERE s.table_schema = DATABASE()
          AND s.table_name = p_table_name
          AND s.index_name = p_index_name
    ) THEN
        SET @sql_stmt = CONCAT(
            'ALTER TABLE `', p_table_name,
            '` ADD ', p_index_definition
        );
        PREPARE stmt FROM @sql_stmt;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

DROP PROCEDURE IF EXISTS frzk_add_fk_if_missing;
DELIMITER $$
CREATE PROCEDURE frzk_add_fk_if_missing(
    IN p_constraint_name VARCHAR(64),
    IN p_alter_statement TEXT
)
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.referential_constraints rc
        WHERE rc.constraint_schema = DATABASE()
          AND rc.constraint_name = p_constraint_name
    ) THEN
        SET @sql_stmt = p_alter_statement;
        PREPARE stmt FROM @sql_stmt;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$
DELIMITER ;

-- ------------------------------------------------------------
-- 1. Repository-Validierungstabelle sicherstellen
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS repository_validation_results (
    validation_result_id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    revision_id BIGINT UNSIGNED NOT NULL,
    validation_code VARCHAR(100) NOT NULL,
    validation_status ENUM('passed','warning','failed') NOT NULL,
    expected_value VARCHAR(255) DEFAULT NULL,
    actual_value VARCHAR(255) DEFAULT NULL,
    validation_message TEXT NOT NULL,
    checked_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (validation_result_id),
    UNIQUE KEY uq_validation_revision_code (revision_id, validation_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CALL frzk_add_index_if_missing(
    'repository_validation_results',
    'idx_validation_revision',
    'INDEX `idx_validation_revision` (`revision_id`)'
);

CALL frzk_add_fk_if_missing(
    'fk_validation_revision',
    'ALTER TABLE `repository_validation_results`
     ADD CONSTRAINT `fk_validation_revision`
     FOREIGN KEY (`revision_id`)
     REFERENCES `repository_revisions` (`revision_id`)
     ON DELETE CASCADE
     ON UPDATE CASCADE'
);

-- ------------------------------------------------------------
-- 2. Revisionsverknüpfung der Gleichungen korrigieren
-- ------------------------------------------------------------

-- Zuerst nullable und typkompatibel machen. Erst danach dürfen Altwerte
-- bereinigt und der Fremdschlüssel angelegt werden.
ALTER TABLE equations
MODIFY COLUMN created_revision_id BIGINT UNSIGNED NULL;

-- Sämtliche ungültigen Revisionswerte entfernen, nicht nur den Altwert 0.
UPDATE equations e
LEFT JOIN repository_revisions rr
  ON rr.revision_id = e.created_revision_id
SET e.created_revision_id = NULL
WHERE e.created_revision_id IS NOT NULL
  AND rr.revision_id IS NULL;

-- Zusätzliche Kontrolle: Nach dieser Abfrage muss COUNT(*) = 0 sein.
SELECT
    COUNT(*) AS invalid_equation_revision_links_before_fk
FROM equations e
LEFT JOIN repository_revisions rr
  ON rr.revision_id = e.created_revision_id
WHERE e.created_revision_id IS NOT NULL
  AND rr.revision_id IS NULL;

CALL frzk_add_index_if_missing(
    'equations',
    'idx_equations_revision',
    'INDEX `idx_equations_revision` (`created_revision_id`)'
);

CALL frzk_add_fk_if_missing(
    'fk_equations_revision',
    'ALTER TABLE `equations`
     ADD CONSTRAINT `fk_equations_revision`
     FOREIGN KEY (`created_revision_id`)
     REFERENCES `repository_revisions` (`revision_id`)
     ON DELETE SET NULL
     ON UPDATE CASCADE'
);

-- Revisionsstände anhand der Gleichungsbereiche nachvollziehbar zuordnen.
SET @rev_initial := (
    SELECT rr.revision_id
    FROM repository_revisions rr
    WHERE rr.revision_code = 'RKB-V4-INITIAL'
    LIMIT 1
);
SET @rev_k32 := (
    SELECT rr.revision_id
    FROM repository_revisions rr
    WHERE rr.revision_code = 'RKB-2026-07-12-K3.2-COMPLETE'
    LIMIT 1
);
SET @rev_k33 := (
    SELECT rr.revision_id
    FROM repository_revisions rr
    WHERE rr.revision_code = 'RKB-2026-07-12-K3.3-NEUFASSUNG'
    LIMIT 1
);
SET @rev_k34 := (
    SELECT rr.revision_id
    FROM repository_revisions rr
    WHERE rr.revision_code = 'RKB-2026-07-12-K3.4-COMPLETE'
    LIMIT 1
);

UPDATE equations e
SET e.created_revision_id = COALESCE(@rev_initial, @audit_revision_id)
WHERE e.created_revision_id IS NULL
  AND CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED) BETWEEN 1 AND 2;

UPDATE equations e
SET e.created_revision_id = COALESCE(@rev_k32, @audit_revision_id)
WHERE e.created_revision_id IS NULL
  AND CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED) BETWEEN 3 AND 86;

UPDATE equations e
SET e.created_revision_id = COALESCE(@rev_k33, @audit_revision_id)
WHERE e.created_revision_id IS NULL
  AND CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED) BETWEEN 87 AND 99;

UPDATE equations e
SET e.created_revision_id = COALESCE(@rev_k34, @audit_revision_id)
WHERE e.created_revision_id IS NULL
  AND CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED) BETWEEN 100 AND 148;

-- ------------------------------------------------------------
-- 3. Revisionsnachverfolgung für Quellen und Verwendungen ergänzen
-- ------------------------------------------------------------

CALL frzk_add_column_if_missing(
    'sources',
    'created_revision_id',
    'BIGINT UNSIGNED NULL AFTER `notes`'
);

CALL frzk_add_column_if_missing(
    'source_usage',
    'created_revision_id',
    'BIGINT UNSIGNED NULL AFTER `notes`'
);

CALL frzk_add_index_if_missing(
    'sources',
    'idx_sources_revision',
    'INDEX `idx_sources_revision` (`created_revision_id`)'
);

CALL frzk_add_index_if_missing(
    'source_usage',
    'idx_source_usage_revision',
    'INDEX `idx_source_usage_revision` (`created_revision_id`)'
);

CALL frzk_add_fk_if_missing(
    'fk_sources_revision',
    'ALTER TABLE `sources`
     ADD CONSTRAINT `fk_sources_revision`
     FOREIGN KEY (`created_revision_id`)
     REFERENCES `repository_revisions` (`revision_id`)
     ON DELETE SET NULL
     ON UPDATE CASCADE'
);

CALL frzk_add_fk_if_missing(
    'fk_source_usage_revision',
    'ALTER TABLE `source_usage`
     ADD CONSTRAINT `fk_source_usage_revision`
     FOREIGN KEY (`created_revision_id`)
     REFERENCES `repository_revisions` (`revision_id`)
     ON DELETE SET NULL
     ON UPDATE CASCADE'
);

UPDATE sources s
SET s.created_revision_id =
    CASE
        WHEN s.citation_number BETWEEN 1 AND 22
            THEN COALESCE(@rev_initial, @audit_revision_id)
        WHEN s.citation_number BETWEEN 23 AND 52
            THEN COALESCE(@rev_k32, @audit_revision_id)
        ELSE @audit_revision_id
    END
WHERE s.created_revision_id IS NULL;

UPDATE source_usage su
JOIN dissertation_sections ds
  ON ds.section_id = su.section_id
SET su.created_revision_id =
    CASE
        WHEN ds.section_code LIKE '3.1%'
            THEN COALESCE(@rev_initial, @audit_revision_id)
        WHEN ds.section_code LIKE '3.2%'
            THEN COALESCE(@rev_k32, @audit_revision_id)
        WHEN ds.section_code LIKE '3.3%'
            THEN COALESCE(@rev_k33, @audit_revision_id)
        WHEN ds.section_code LIKE '3.4%'
            THEN COALESCE(@rev_k34, @audit_revision_id)
        ELSE @audit_revision_id
    END
WHERE su.created_revision_id IS NULL;

-- ------------------------------------------------------------
-- 4. Zeitstempel der Kapitelstruktur ergänzen
-- ------------------------------------------------------------

CALL frzk_add_column_if_missing(
    'dissertation_sections',
    'created_at',
    'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP'
);

CALL frzk_add_column_if_missing(
    'dissertation_sections',
    'updated_at',
    'TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'
);

-- ------------------------------------------------------------
-- 5. Zusätzliche sinnvolle Indizes
-- ------------------------------------------------------------

CALL frzk_add_index_if_missing(
    'source_usage',
    'idx_source_usage_section_source',
    'INDEX `idx_source_usage_section_source` (`section_id`, `source_id`)'
);

CALL frzk_add_index_if_missing(
    'equations',
    'idx_equations_section_number',
    'INDEX `idx_equations_section_number` (`section_id`, `equation_number`)'
);

CALL frzk_add_index_if_missing(
    'definitions',
    'idx_definitions_section',
    'INDEX `idx_definitions_section` (`section_id`)'
);

CALL frzk_add_index_if_missing(
    'proofs',
    'idx_proofs_section_status',
    'INDEX `idx_proofs_section_status` (`section_id`, `validation_status`)'
);

-- ------------------------------------------------------------
-- 6. Repository-Zähler verbindlich aktualisieren
-- ------------------------------------------------------------

INSERT INTO repository_counters(counter_key, counter_value)
VALUES
('next_citation_number', '53'),
('next_equation_number', '3.149'),
('last_completed_section', '3.4'),
('last_repository_revision', 'RKB-2026-07-12-AUDIT-K3.4')
ON DUPLICATE KEY UPDATE
 counter_value = VALUES(counter_value),
 updated_at = CURRENT_TIMESTAMP;

-- ------------------------------------------------------------
-- 7. Validierungsergebnisse des Audits neu erzeugen
-- ------------------------------------------------------------

DELETE FROM repository_validation_results
WHERE revision_id = @audit_revision_id;

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'SOURCE_NUMBER_RANGE',
    IF(
        COUNT(*) = 52
        AND COUNT(DISTINCT s.citation_number) = 52
        AND MIN(s.citation_number) = 1
        AND MAX(s.citation_number) = 52,
        'passed', 'failed'
    ),
    '52 eindeutige Nummern [1] bis [52]',
    CONCAT(
        'Anzahl=', COUNT(*),
        '; eindeutig=', COUNT(DISTINCT s.citation_number),
        '; min=', MIN(s.citation_number),
        '; max=', MAX(s.citation_number)
    ),
    'Prüft Vollständigkeit, Eindeutigkeit und Lückenfreiheit der Literaturnummern.'
FROM sources s;

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'SOURCE_ANNOTATION_COUNT',
    IF(COUNT(*) = 52, 'passed', 'failed'),
    '52 Annotationen',
    CAST(COUNT(*) AS CHAR),
    'Jede der 52 Quellen muss genau eine Annotation besitzen.'
FROM annotations a;

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'EQUATION_NUMBER_RANGE',
    IF(
        COUNT(*) = 148
        AND COUNT(DISTINCT e.equation_number) = 148
        AND MIN(CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED)) = 1
        AND MAX(CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED)) = 148,
        'passed', 'failed'
    ),
    '148 eindeutige Gleichungen (3.1) bis (3.148)',
    CONCAT(
        'Anzahl=', COUNT(*),
        '; eindeutig=', COUNT(DISTINCT e.equation_number),
        '; min=', MIN(CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED)),
        '; max=', MAX(CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED))
    ),
    'Prüft den vollständigen Gleichungsnummernbereich bis Kapitel 3.4.'
FROM equations e
WHERE e.equation_number LIKE '3.%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'EQUATION_WORD_LATEX',
    IF(COUNT(*) = 0, 'passed', 'failed'),
    '0 fehlende Word-LaTeX-Einträge',
    CAST(COUNT(*) AS CHAR),
    'Jede Gleichung muss eine Word-kompatible LaTeX-Darstellung besitzen.'
FROM equations e
WHERE e.word_latex IS NULL OR TRIM(e.word_latex) = '';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'EQUATION_REVISION_LINKS',
    IF(COUNT(*) = 0, 'passed', 'failed'),
    '0 Gleichungen ohne gültige Revision',
    CAST(COUNT(*) AS CHAR),
    'Prüft die Revisionsverknüpfung aller Gleichungen.'
FROM equations e
LEFT JOIN repository_revisions rr
  ON rr.revision_id = e.created_revision_id
WHERE e.created_revision_id IS NULL OR rr.revision_id IS NULL;

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'K3_4_SECTION_COUNT',
    IF(COUNT(*) = 12, 'passed', 'failed'),
    '12 Datensätze: 3.4 sowie 3.4.0 bis 3.4.10',
    CAST(COUNT(*) AS CHAR),
    'Prüft die vollständige Abschnittsstruktur von Kapitel 3.4.'
FROM dissertation_sections ds
WHERE ds.section_code = '3.4'
   OR ds.section_code LIKE '3.4.%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'K3_4_DEFINITION_COUNT',
    IF(COUNT(*) = 17, 'passed', 'failed'),
    '17 Definitionen',
    CAST(COUNT(*) AS CHAR),
    'Prüft die registrierten Definitionen von Kapitel 3.4.'
FROM definitions d
JOIN dissertation_sections ds
  ON ds.section_id = d.section_id
WHERE ds.section_code LIKE '3.4%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'K3_4_LEMMA_COUNT',
    IF(COUNT(*) = 16, 'passed', 'failed'),
    '16 Lemmata',
    CAST(COUNT(*) AS CHAR),
    'Prüft die registrierten Lemmata von Kapitel 3.4.'
FROM lemmas l
JOIN dissertation_sections ds
  ON ds.section_id = l.section_id
WHERE ds.section_code LIKE '3.4%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'K3_4_THEOREM_COUNT',
    IF(COUNT(*) = 8, 'passed', 'failed'),
    '8 Sätze',
    CAST(COUNT(*) AS CHAR),
    'Prüft die registrierten Sätze von Kapitel 3.4.'
FROM theorems t
JOIN dissertation_sections ds
  ON ds.section_id = t.section_id
WHERE ds.section_code LIKE '3.4%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'K3_4_COROLLARY_COUNT',
    IF(COUNT(*) = 7, 'passed', 'failed'),
    '7 Korollare',
    CAST(COUNT(*) AS CHAR),
    'Prüft die registrierten Korollare von Kapitel 3.4.'
FROM corollaries c
JOIN dissertation_sections ds
  ON ds.section_id = c.section_id
WHERE ds.section_code LIKE '3.4%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'K3_4_PROOF_COUNT',
    IF(COUNT(*) = 31, 'passed', 'failed'),
    '31 Beweisdatensätze',
    CAST(COUNT(*) AS CHAR),
    'Prüft die Anzahl der registrierten Beweisdatensätze.'
FROM proofs p
JOIN dissertation_sections ds
  ON ds.section_id = p.section_id
WHERE ds.section_code LIKE '3.4%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'K3_4_PROOF_STATUS',
    IF(
        SUM(CASE WHEN p.validation_status = 'draft' THEN 1 ELSE 0 END) = COUNT(*),
        'passed', 'warning'
    ),
    'Alle 31 Beweise im Status draft bis zur mathematischen Endprüfung',
    CONCAT(
        'gesamt=', COUNT(*),
        '; draft=', SUM(CASE WHEN p.validation_status = 'draft' THEN 1 ELSE 0 END)
    ),
    'Der Status draft ist beabsichtigt; die formale mathematische Prüfung steht noch aus.'
FROM proofs p
JOIN dissertation_sections ds
  ON ds.section_id = p.section_id
WHERE ds.section_code LIKE '3.4%';

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'ORPHAN_SOURCE_USAGE',
    IF(COUNT(*) = 0, 'passed', 'failed'),
    '0 verwaiste Quellenverwendungen',
    CAST(COUNT(*) AS CHAR),
    'Prüft, ob jede Quellenverwendung eine vorhandene Quelle und einen vorhandenen Abschnitt besitzt.'
FROM source_usage su
LEFT JOIN sources s
  ON s.source_id = su.source_id
LEFT JOIN dissertation_sections ds
  ON ds.section_id = su.section_id
WHERE s.source_id IS NULL OR ds.section_id IS NULL;

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'ORPHAN_EQUATION_SECTION',
    IF(COUNT(*) = 0, 'passed', 'failed'),
    '0 Gleichungen ohne Abschnitt',
    CAST(COUNT(*) AS CHAR),
    'Prüft die Abschnittszuordnung aller Gleichungen.'
FROM equations e
LEFT JOIN dissertation_sections ds
  ON ds.section_id = e.section_id
WHERE ds.section_id IS NULL;

INSERT INTO repository_validation_results
(revision_id, validation_code, validation_status,
 expected_value, actual_value, validation_message)
SELECT
    @audit_revision_id,
    'SOURCE_AUTHOR_COVERAGE',
    CASE
        WHEN COUNT(DISTINCT sa.source_id) = COUNT(DISTINCT s.source_id)
            THEN 'passed'
        ELSE 'warning'
    END,
    'Alle Quellen besitzen strukturierte Autorenzuordnungen',
    CONCAT(
        COUNT(DISTINCT sa.source_id), ' von ',
        COUNT(DISTINCT s.source_id), ' Quellen'
    ),
    'Fehlende strukturierte Autorenzuordnungen beeinträchtigen nicht die feste Literaturzählung, sollten aber später ergänzt werden.'
FROM sources s
LEFT JOIN source_authors sa
  ON sa.source_id = s.source_id;

-- ------------------------------------------------------------
-- 8. Audit im Änderungsprotokoll dokumentieren
-- ------------------------------------------------------------

INSERT INTO section_change_log
(revision_id, section_id, change_type, object_type, object_reference,
 change_summary, previous_value, new_value)
SELECT
    @audit_revision_id,
    ds.section_id,
    'other',
    'repository',
    'Audit bis Kapitel 3.4',
    'Schema-, Fremdschlüssel-, Nummerierungs- und Vollständigkeitsprüfung durchgeführt.',
    NULL,
    'Repository-Version 4.1'
FROM dissertation_sections ds
WHERE ds.section_code = '3.4'
ON DUPLICATE KEY UPDATE
 change_summary = VALUES(change_summary),
 new_value = VALUES(new_value);

-- ------------------------------------------------------------
-- 9. Hilfsprozeduren entfernen
-- ------------------------------------------------------------

DROP PROCEDURE IF EXISTS frzk_add_column_if_missing;
DROP PROCEDURE IF EXISTS frzk_add_index_if_missing;
DROP PROCEDURE IF EXISTS frzk_add_fk_if_missing;

-- ------------------------------------------------------------
-- 10. Kontrollausgaben
-- ------------------------------------------------------------

SELECT
    DATABASE() AS active_database,
    VERSION() AS database_version;

SELECT
    rvr.validation_code,
    rvr.validation_status,
    rvr.expected_value,
    rvr.actual_value,
    rvr.validation_message
FROM frzk_rkb.repository_validation_results rvr
WHERE rvr.revision_id = @audit_revision_id
ORDER BY rvr.validation_status, rvr.validation_code;

SELECT
    rc.counter_key,
    rc.counter_value
FROM frzk_rkb.repository_counters rc
ORDER BY rc.counter_key;
