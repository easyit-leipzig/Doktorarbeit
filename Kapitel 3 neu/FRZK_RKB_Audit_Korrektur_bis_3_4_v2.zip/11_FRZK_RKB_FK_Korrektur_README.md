# Korrektur des Fremdschlüsselfehlers #1452

## Ursache

`equations.created_revision_id` war im Ausgangsschema als

```sql
INT NOT NULL
```

definiert. Der bisherige Ablauf versuchte zuerst, ungültige Werte auf `NULL`
zu setzen. Das ist bei einer `NOT NULL`-Spalte nicht zuverlässig möglich.
Dadurch konnten ungültige Werte bestehen bleiben und das Anlegen des
Fremdschlüssels scheiterte mit `#1452`.

## Korrigierte Reihenfolge

1. Spalte auf `BIGINT UNSIGNED NULL` ändern.
2. Alle Revisionswerte ohne passendes Elternobjekt auf `NULL` setzen.
3. Kontrollieren, dass keine ungültigen Werte mehr bestehen.
4. Index und Fremdschlüssel anlegen.
5. Die Gleichungen anschließend den passenden Kapitelrevisionen zuordnen.

Die Bereinigung erfasst bewusst nicht nur den Wert `0`, sondern jeden
verwaisten Revisionswert:

```sql
UPDATE equations e
LEFT JOIN repository_revisions rr
  ON rr.revision_id = e.created_revision_id
SET e.created_revision_id = NULL
WHERE e.created_revision_id IS NOT NULL
  AND rr.revision_id IS NULL;
```

## Import in die bestehende Datenbank

Falls das vorige Skript am Fremdschlüssel abgebrochen ist, kann die
korrigierte Fassung erneut vollständig ausgeführt werden:

```bash
mysql -u root frzk_rkb < 11_frzk_rkb_audit_korrektur_verbesserung_bis_3_4_korrigiert.sql
```

## Vollständiger Neuimport

```bash
mysql -u root < frzk_rkb_bis_3_4_auditiert_korrigiert_v2.sql
```
