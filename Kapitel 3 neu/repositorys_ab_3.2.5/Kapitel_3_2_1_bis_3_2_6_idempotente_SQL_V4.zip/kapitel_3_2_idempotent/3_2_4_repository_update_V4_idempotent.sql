USE `frzk_rkb`;
SET NAMES utf8mb4;
START TRANSACTION;
/* Abschnitt 3.2.4 – vollständige Neufassung V2
   Voraussetzung: 3_2_3_neufassung_repository_update_V2_korrigiert.sql wurde ausgeführt.
   Neue Quellen [61]–[65]. Gleichungen (3.65)–(3.106). */
SET @parent_revision_id := (SELECT `revision_id` FROM `repository_revisions` WHERE `revision_code`='RKB-2026-07-14-K3.2.3-NEUFASSUNG-V2' LIMIT 1);
INSERT INTO `repository_revisions` (`revision_code`,`revision_date`,`scope_type`,`scope_reference`,`version_label`,`summary`,`created_by`,`parent_revision_id`) VALUES ('RKB-2026-07-14-K3.2.4-NEUFASSUNG-V2',NOW(),'section','3.2.4','2.0','Vollständige Neufassung von Abschnitt 3.2.4 mit Magmen, Halbgruppen, Monoiden, Gruppen, Ringen, Körpern, Vektorräumen, Homomorphismen und Symmetriebezug.','Olaf Thiele / ChatGPT',@parent_revision_id) ON DUPLICATE KEY UPDATE `revision_id`=LAST_INSERT_ID(`revision_id`),`revision_date`=VALUES(`revision_date`),`summary`=VALUES(`summary`),`parent_revision_id`=VALUES(`parent_revision_id`);
SET @revision_id := (SELECT `revision_id` FROM `repository_revisions` WHERE `revision_code`='RKB-2026-07-14-K3.2.4-NEUFASSUNG-V2' LIMIT 1);
SET @section_id:=(SELECT `section_id` FROM `dissertation_sections` WHERE `section_code`='3.2.4' LIMIT 1);

/* ============================================================
   REPARATUR DER GLOBALEN GLEICHUNGSNUMMERIERUNG

   Die Neufassung von 3.2.4 verwendet (3.65)–(3.106).
   Im bisherigen Repository beginnen 3.3 und 3.4 bereits bei (3.87).
   Da equation_number global eindeutig ist, müssen die alten fachlichen
   Artefakte von 3.3 und 3.4 vorübergehend entfernt werden. Die
   Abschnittsgerüste und Literaturquellen bleiben erhalten. 3.3 und 3.4
   werden später mit der neuen fortlaufenden Nummerierung neu aufgebaut.
   ============================================================ */
DROP TEMPORARY TABLE IF EXISTS `tmp_downstream_sections_324`;
CREATE TEMPORARY TABLE `tmp_downstream_sections_324` (
  `section_id` BIGINT UNSIGNED PRIMARY KEY
) ENGINE=MEMORY;

INSERT INTO `tmp_downstream_sections_324` (`section_id`)
SELECT `section_id`
FROM `dissertation_sections`
WHERE `section_code` LIKE '3.3%'
   OR `section_code` LIKE '3.4%';

/* abhängige Gleichungsobjekte zuerst entfernen */
DELETE es
FROM `equation_symbols` es
JOIN `equations` e ON e.`equation_id`=es.`equation_id`
JOIN `tmp_downstream_sections_324` t ON t.`section_id`=e.`section_id`;

DELETE ed
FROM `equation_dependencies` ed
JOIN `equations` e ON e.`equation_id`=ed.`equation_id`
JOIN `tmp_downstream_sections_324` t ON t.`section_id`=e.`section_id`;

DELETE ed
FROM `equation_dependencies` ed
JOIN `equations` e ON e.`equation_id`=ed.`depends_on_equation_id`
JOIN `tmp_downstream_sections_324` t ON t.`section_id`=e.`section_id`;

DELETE osl
FROM `object_source_links` osl
WHERE (`osl`.`object_type`='equation' AND `osl`.`object_id` IN (
         SELECT e.`equation_id` FROM `equations` e
         JOIN `tmp_downstream_sections_324` t ON t.`section_id`=e.`section_id`
       ))
   OR (`osl`.`object_type`='definition' AND `osl`.`object_id` IN (
         SELECT d.`definition_id` FROM `definitions` d
         JOIN `tmp_downstream_sections_324` t ON t.`section_id`=d.`section_id`
       ));

DELETE od
FROM `object_dependencies` od
WHERE (`od`.`object_type_from`='equation' AND `od`.`object_id_from` IN (
         SELECT e.`equation_id` FROM `equations` e
         JOIN `tmp_downstream_sections_324` t ON t.`section_id`=e.`section_id`
       ))
   OR (`od`.`object_type_to`='equation' AND `od`.`object_id_to` IN (
         SELECT e.`equation_id` FROM `equations` e
         JOIN `tmp_downstream_sections_324` t ON t.`section_id`=e.`section_id`
       ));

DELETE pd
FROM `proposition_dependencies` pd
JOIN `propositions` p ON p.`proposition_id`=pd.`proposition_id`
JOIN `tmp_downstream_sections_324` t ON t.`section_id`=p.`section_id`;

DELETE ad
FROM `axiom_dependencies` ad
JOIN `axioms` a ON a.`axiom_id`=ad.`axiom_id`
JOIN `tmp_downstream_sections_324` t ON t.`section_id`=a.`section_id`;

DELETE FROM `proofs` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `corollaries` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `lemmas` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `theorems` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `propositions` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `axioms` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `assumptions` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `figures` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `dissertation_tables` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `definitions` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `equations` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `source_usage` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `symbols` WHERE `first_section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);
DELETE FROM `section_change_log` WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);

UPDATE `dissertation_sections`
SET `status`='planned',
    `notes`='Inhaltliche Repository-Artefakte wegen neuer globaler Gleichungsnummerierung ab 3.2.4 zurückgesetzt; Neuaufbau folgt.'
WHERE `section_id` IN (SELECT `section_id` FROM `tmp_downstream_sections_324`);

/* Sicherheitsprüfung: Nach der Bereinigung darf die Nummer (3.87)
   nicht mehr vorhanden sein. */
SET @conflict_count := (
  SELECT COUNT(*) FROM `equations`
  WHERE CAST(SUBSTRING_INDEX(`equation_number`,'.',-1) AS UNSIGNED) BETWEEN 65 AND 106
    AND `section_id` <> @section_id
);

/* Ein absichtlicher Fehler wird erzeugt, falls trotz Bereinigung noch
   globale Nummernkonflikte vorhanden sind. */
DROP TEMPORARY TABLE IF EXISTS `tmp_assert_no_equation_conflict_324`;
CREATE TEMPORARY TABLE `tmp_assert_no_equation_conflict_324` (`ok` TINYINT NOT NULL, UNIQUE KEY (`ok`));
INSERT INTO `tmp_assert_no_equation_conflict_324` (`ok`) VALUES (1);
INSERT INTO `tmp_assert_no_equation_conflict_324` (`ok`)
SELECT 1 WHERE @conflict_count > 0;
UPDATE `dissertation_sections` SET `title`='Algebraische Strukturen als Grundlage regelhafter Verknüpfungen',`status`='review',`is_original_contribution`=0,`notes`='Vollständige Neufassung V2 mit Quellen [61]–[65] und Gleichungen (3.65)–(3.106).' WHERE `section_id`=@section_id;
DELETE es FROM `equation_symbols` es JOIN `equations` e ON e.`equation_id`=es.`equation_id` WHERE e.`section_id`=@section_id;
DELETE FROM `equations` WHERE `section_id`=@section_id;
DELETE FROM `definitions` WHERE `section_id`=@section_id;
DELETE FROM `source_usage` WHERE `section_id`=@section_id;
DELETE FROM `symbols` WHERE `first_section_id`=@section_id AND `scope_type`='section';
INSERT INTO `authors` (`family_name`,`given_names`,`normalized_name`,`birth_year`,`death_year`,`notes`) VALUES ('Galois','Évariste','Galois, Évariste',1811,1832,'Primärquelle zur Entstehung der Gruppentheorie.') ON DUPLICATE KEY UPDATE `author_id`=LAST_INSERT_ID(`author_id`),`notes`=VALUES(`notes`);
SET @author_9:=LAST_INSERT_ID();
INSERT INTO `authors` (`family_name`,`given_names`,`normalized_name`,`birth_year`,`death_year`,`notes`) VALUES ('Noether','Emmy','Noether, Emmy',1882,1935,'Primärquellen zur strukturellen Algebra und zum Symmetrie-Erhaltungssatz.') ON DUPLICATE KEY UPDATE `author_id`=LAST_INSERT_ID(`author_id`),`notes`=VALUES(`notes`);
SET @author_10:=LAST_INSERT_ID();
INSERT INTO `authors` (`family_name`,`given_names`,`normalized_name`,`birth_year`,`death_year`,`notes`) VALUES ('van der Waerden','Bartel Leendert','van der Waerden, Bartel Leendert',1903,1996,'Systematische Darstellung der modernen abstrakten Algebra.') ON DUPLICATE KEY UPDATE `author_id`=LAST_INSERT_ID(`author_id`),`notes`=VALUES(`notes`);
SET @author_11:=LAST_INSERT_ID();
INSERT INTO `authors` (`family_name`,`given_names`,`normalized_name`,`birth_year`,`death_year`,`notes`) VALUES ('Mac Lane','Saunders','Mac Lane, Saunders',1909,2005,'Mitautor eines Standardwerks der abstrakten Algebra.') ON DUPLICATE KEY UPDATE `author_id`=LAST_INSERT_ID(`author_id`),`notes`=VALUES(`notes`);
SET @author_12:=LAST_INSERT_ID();
INSERT INTO `authors` (`family_name`,`given_names`,`normalized_name`,`birth_year`,`death_year`,`notes`) VALUES ('Birkhoff','Garrett','Birkhoff, Garrett',1911,1996,'Mitautor eines Standardwerks der abstrakten Algebra.') ON DUPLICATE KEY UPDATE `author_id`=LAST_INSERT_ID(`author_id`),`notes`=VALUES(`notes`);
SET @author_13:=LAST_INSERT_ID();
SET @author_galois:=(SELECT `author_id` FROM `authors` WHERE `normalized_name`='Galois, Évariste' LIMIT 1);
SET @author_noether:=(SELECT `author_id` FROM `authors` WHERE `normalized_name`='Noether, Emmy' LIMIT 1);
SET @author_vdw:=(SELECT `author_id` FROM `authors` WHERE `normalized_name`='van der Waerden, Bartel Leendert' LIMIT 1);
SET @author_maclane:=(SELECT `author_id` FROM `authors` WHERE `normalized_name`='Mac Lane, Saunders' LIMIT 1);
SET @author_birkhoff:=(SELECT `author_id` FROM `authors` WHERE `normalized_name`='Birkhoff, Garrett' LIMIT 1);
INSERT INTO `sources` (`citation_number`,`source_key`,`source_type`,`title`,`year_original`,`year_edition`,`journal`,`publisher`,`place`,`volume`,`issue`,`pages`,`language_code`,`priority`,`evidence_type`,`frzk_relevance`,`verification_status`,`first_citation_section_code`,`first_citation_note`,`full_citation_text`,`short_citation_text`,`notes`,`created_revision_id`) VALUES (61,'galois_resolubilite_1846','journal_article','Mémoire sur les conditions de résolubilité des équations par radicaux',1831,1846,'Journal de Mathématiques Pures et Appliquées',NULL,NULL,'11',NULL,'417–433','fr',5,'primary',4,'partially_verified','3.2.4','Historische Primärquelle zur Entstehung der Gruppentheorie.','Galois, Évariste: Mémoire sur les conditions de résolubilité des équations par radicaux. Eingereicht 1831; veröffentlicht in: Journal de Mathématiques Pures et Appliquées, Bd. 11, 1846, S. 417–433.','Galois [61]','Primärquelle zur Symmetriestruktur algebraischer Gleichungen.',@revision_id) ON DUPLICATE KEY UPDATE `source_id`=LAST_INSERT_ID(`source_id`),`source_key`=VALUES(`source_key`),`title`=VALUES(`title`),`full_citation_text`=VALUES(`full_citation_text`),`verification_status`=VALUES(`verification_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @source_61_id:=LAST_INSERT_ID();
INSERT INTO `sources` (`citation_number`,`source_key`,`source_type`,`title`,`year_original`,`year_edition`,`journal`,`publisher`,`place`,`volume`,`issue`,`pages`,`language_code`,`priority`,`evidence_type`,`frzk_relevance`,`verification_status`,`first_citation_section_code`,`first_citation_note`,`full_citation_text`,`short_citation_text`,`notes`,`created_revision_id`) VALUES (62,'noether_idealtheorie_1921','journal_article','Idealtheorie in Ringbereichen',1921,1921,'Mathematische Annalen',NULL,NULL,'83',NULL,'24–66','de',5,'primary',5,'verified','3.2.4','Primärquelle zur strukturellen Ring- und Idealtheorie.','Noether, Emmy: Idealtheorie in Ringbereichen. Mathematische Annalen, Bd. 83, 1921, S. 24–66.','Noether [62]','Grundlage der modernen strukturellen Algebra.',@revision_id) ON DUPLICATE KEY UPDATE `source_id`=LAST_INSERT_ID(`source_id`),`source_key`=VALUES(`source_key`),`title`=VALUES(`title`),`full_citation_text`=VALUES(`full_citation_text`),`verification_status`=VALUES(`verification_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @source_62_id:=LAST_INSERT_ID();
INSERT INTO `sources` (`citation_number`,`source_key`,`source_type`,`title`,`year_original`,`year_edition`,`journal`,`publisher`,`place`,`volume`,`issue`,`pages`,`language_code`,`priority`,`evidence_type`,`frzk_relevance`,`verification_status`,`first_citation_section_code`,`first_citation_note`,`full_citation_text`,`short_citation_text`,`notes`,`created_revision_id`) VALUES (63,'van_der_waerden_moderne_algebra_1930','book','Moderne Algebra',1930,1931,NULL,'Springer','Berlin',NULL,NULL,NULL,'de',5,'secondary',5,'partially_verified','3.2.4','Systematische Darstellung abstrakter algebraischer Strukturen.','van der Waerden, Bartel Leendert: Moderne Algebra. Berlin: Springer, 1930–1931.','van der Waerden [63]','Standardwerk zur strukturellen Algebra.',@revision_id) ON DUPLICATE KEY UPDATE `source_id`=LAST_INSERT_ID(`source_id`),`source_key`=VALUES(`source_key`),`title`=VALUES(`title`),`full_citation_text`=VALUES(`full_citation_text`),`verification_status`=VALUES(`verification_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @source_63_id:=LAST_INSERT_ID();
INSERT INTO `sources` (`citation_number`,`source_key`,`source_type`,`title`,`year_original`,`year_edition`,`journal`,`publisher`,`place`,`volume`,`issue`,`pages`,`language_code`,`priority`,`evidence_type`,`frzk_relevance`,`verification_status`,`first_citation_section_code`,`first_citation_note`,`full_citation_text`,`short_citation_text`,`notes`,`created_revision_id`) VALUES (64,'mac_lane_birkhoff_algebra_1988','book','Algebra',1967,1988,NULL,'Chelsea Publishing','New York',NULL,NULL,NULL,'en',4,'secondary',4,'partially_verified','3.2.4','Standardreferenz zu Gruppen, Homomorphismen und algebraischen Strukturen.','Mac Lane, Saunders; Birkhoff, Garrett: Algebra. 3. Auflage. New York: Chelsea Publishing, 1988.','Mac Lane/Birkhoff [64]','Standardwerk der abstrakten Algebra.',@revision_id) ON DUPLICATE KEY UPDATE `source_id`=LAST_INSERT_ID(`source_id`),`source_key`=VALUES(`source_key`),`title`=VALUES(`title`),`full_citation_text`=VALUES(`full_citation_text`),`verification_status`=VALUES(`verification_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @source_64_id:=LAST_INSERT_ID();
INSERT INTO `sources` (`citation_number`,`source_key`,`source_type`,`title`,`year_original`,`year_edition`,`journal`,`publisher`,`place`,`volume`,`issue`,`pages`,`language_code`,`priority`,`evidence_type`,`frzk_relevance`,`verification_status`,`first_citation_section_code`,`first_citation_note`,`full_citation_text`,`short_citation_text`,`notes`,`created_revision_id`) VALUES (65,'noether_invariante_variationsprobleme_1918','journal_article','Invariante Variationsprobleme',1918,1918,'Nachrichten von der Gesellschaft der Wissenschaften zu Göttingen, Mathematisch-Physikalische Klasse',NULL,NULL,NULL,NULL,'235–257','de',5,'primary',5,'verified','3.2.4','Primärquelle zum Zusammenhang von kontinuierlichen Symmetrien und Erhaltungssätzen.','Noether, Emmy: Invariante Variationsprobleme. Nachrichten von der Gesellschaft der Wissenschaften zu Göttingen, Mathematisch-Physikalische Klasse, 1918, S. 235–257.','Noether [65]','Primärquelle zum Noether-Theorem.',@revision_id) ON DUPLICATE KEY UPDATE `source_id`=LAST_INSERT_ID(`source_id`),`source_key`=VALUES(`source_key`),`title`=VALUES(`title`),`full_citation_text`=VALUES(`full_citation_text`),`verification_status`=VALUES(`verification_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @source_65_id:=LAST_INSERT_ID();
DELETE FROM `source_authors` WHERE `source_id`=@source_61_id;
INSERT INTO `source_authors` (`source_id`,`author_id`,`author_order`,`role`) VALUES (@source_61_id,@author_galois,1,'author')
ON DUPLICATE KEY UPDATE
  `author_order`=VALUES(`author_order`),
  `role`=VALUES(`role`);
DELETE FROM `source_authors` WHERE `source_id`=@source_62_id;
INSERT INTO `source_authors` (`source_id`,`author_id`,`author_order`,`role`) VALUES (@source_62_id,@author_noether,1,'author')
ON DUPLICATE KEY UPDATE
  `author_order`=VALUES(`author_order`),
  `role`=VALUES(`role`);
DELETE FROM `source_authors` WHERE `source_id`=@source_63_id;
INSERT INTO `source_authors` (`source_id`,`author_id`,`author_order`,`role`) VALUES (@source_63_id,@author_vdw,1,'author')
ON DUPLICATE KEY UPDATE
  `author_order`=VALUES(`author_order`),
  `role`=VALUES(`role`);
DELETE FROM `source_authors` WHERE `source_id`=@source_64_id;
INSERT INTO `source_authors` (`source_id`,`author_id`,`author_order`,`role`) VALUES (@source_64_id,@author_maclane,1,'author')
ON DUPLICATE KEY UPDATE
  `author_order`=VALUES(`author_order`),
  `role`=VALUES(`role`);
INSERT INTO `source_authors` (`source_id`,`author_id`,`author_order`,`role`) VALUES (@source_64_id,@author_birkhoff,2,'author')
ON DUPLICATE KEY UPDATE
  `author_order`=VALUES(`author_order`),
  `role`=VALUES(`role`);
DELETE FROM `source_authors` WHERE `source_id`=@source_65_id;
INSERT INTO `source_authors` (`source_id`,`author_id`,`author_order`,`role`) VALUES (@source_65_id,@author_noether,1,'author')
ON DUPLICATE KEY UPDATE
  `author_order`=VALUES(`author_order`),
  `role`=VALUES(`role`);
DELETE FROM `annotations` WHERE `source_id`=@source_61_id;
INSERT INTO `annotations` (`source_id`,`contribution`,`significance_for_dissertation`,`citation_reason`,`adopted_claims`,`limitations`,`scientific_discussion`,`annotation_status`,`reviewed_at`) VALUES (@source_61_id,'Historische Primärquelle zur gruppentheoretischen Analyse der Lösbarkeit algebraischer Gleichungen.','Begründet den historischen Übergang von Rechenverfahren zu abstrakten Symmetriestrukturen.','Erstnennung zur Entstehung der Gruppentheorie.','Symmetrien der Nullstellen bestimmen die Lösbarkeit durch Radikale.','Historische Primärquelle in älterer Terminologie.','Wird durch moderne algebraische Standardwerke formal präzisiert.','reviewed',NOW());
DELETE FROM `annotations` WHERE `source_id`=@source_62_id;
INSERT INTO `annotations` (`source_id`,`contribution`,`significance_for_dissertation`,`citation_reason`,`adopted_claims`,`limitations`,`scientific_discussion`,`annotation_status`,`reviewed_at`) VALUES (@source_62_id,'Begründet die abstrakte Ideal- und Ringtheorie in axiomatischer Form.','Zentrale Quelle für den strukturellen Paradigmenwechsel der Algebra.','Belegt die systematische Ablösung algebraischer Aussagen von konkreten Zahlbereichen.','Ring- und Idealstrukturen können allgemein axiomatisch untersucht werden.','Fokussiert auf Ringbereiche und Idealtheorie.','Wird mit van der Waerden [63] systematisch eingeordnet.','reviewed',NOW());
DELETE FROM `annotations` WHERE `source_id`=@source_63_id;
INSERT INTO `annotations` (`source_id`,`contribution`,`significance_for_dissertation`,`citation_reason`,`adopted_claims`,`limitations`,`scientific_discussion`,`annotation_status`,`reviewed_at`) VALUES (@source_63_id,'Systematisiert Gruppen, Ringe, Körper und weitere algebraische Strukturen.','Formale Hauptreferenz für die Definitionen in Abschnitt 3.2.4.','Belegt die axiomatische Strukturhierarchie der abstrakten Algebra.','Algebraische Strukturen werden durch Trägermengen, Operationen und Axiome bestimmt.','Historisches Standardwerk; moderne Terminologie kann abweichen.','Wird durch Mac Lane/Birkhoff [64] ergänzt.','reviewed',NOW());
DELETE FROM `annotations` WHERE `source_id`=@source_64_id;
INSERT INTO `annotations` (`source_id`,`contribution`,`significance_for_dissertation`,`citation_reason`,`adopted_claims`,`limitations`,`scientific_discussion`,`annotation_status`,`reviewed_at`) VALUES (@source_64_id,'Stellt Gruppen, Homomorphismen und Isomorphismen in moderner struktureller Form dar.','Referenz für Gruppen, Untergruppen und strukturerhaltende Abbildungen.','Belegt die strukturelle Gleichwertigkeit isomorpher algebraischer Objekte.','Homomorphismen erhalten Verknüpfungsstrukturen.','Lehrbuchdarstellung statt Primärquelle.','Ergänzt die historischen Primärquellen.','reviewed',NOW());
DELETE FROM `annotations` WHERE `source_id`=@source_65_id;
INSERT INTO `annotations` (`source_id`,`contribution`,`significance_for_dissertation`,`citation_reason`,`adopted_claims`,`limitations`,`scientific_discussion`,`annotation_status`,`reviewed_at`) VALUES (@source_65_id,'Beweist den Zusammenhang kontinuierlicher Symmetrien mit Erhaltungssätzen.','Belegt die wissenschaftliche Bedeutung von Gruppen als Symmetriemodelle.','Primärquelle zur Verbindung von Algebra und theoretischer Physik.','Kontinuierliche Symmetrien führen zu Erhaltungsgrößen.','Setzt variationsanalytische Voraussetzungen voraus.','Dient als Anwendungsbezug der Gruppentheorie.','reviewed',NOW());
INSERT INTO `source_usage` (`source_id`,`section_id`,`usage_type`,`claim_summary`,`exact_location`,`is_first_mention`,`citation_checked`,`notes`,`created_revision_id`) VALUES (@source_61_id,@section_id,'first_citation','Historische Entstehung der Gruppentheorie aus der Analyse algebraischer Gleichungen.','Einleitung 3.2.4',1,1,'Neufassung 3.2.4 V2.',@revision_id);
INSERT INTO `source_usage` (`source_id`,`section_id`,`usage_type`,`claim_summary`,`exact_location`,`is_first_mention`,`citation_checked`,`notes`,`created_revision_id`) VALUES (@source_62_id,@section_id,'first_citation','Strukturelle Ring- und Idealtheorie als Wendepunkt der modernen Algebra.','Einleitung sowie Ringabschnitt 3.2.4',1,1,'Neufassung 3.2.4 V2.',@revision_id);
INSERT INTO `source_usage` (`source_id`,`section_id`,`usage_type`,`claim_summary`,`exact_location`,`is_first_mention`,`citation_checked`,`notes`,`created_revision_id`) VALUES (@source_63_id,@section_id,'first_citation','Systematische Definition algebraischer Grundstrukturen von der binären Verknüpfung bis zum Vektorraum.','Definitionen und Strukturhierarchie 3.2.4',1,1,'Neufassung 3.2.4 V2.',@revision_id);
INSERT INTO `source_usage` (`source_id`,`section_id`,`usage_type`,`claim_summary`,`exact_location`,`is_first_mention`,`citation_checked`,`notes`,`created_revision_id`) VALUES (@source_64_id,@section_id,'first_citation','Gruppen, Untergruppen, Homomorphismen und Isomorphismen.','Gruppenabschnitt 3.2.4',1,1,'Neufassung 3.2.4 V2.',@revision_id);
INSERT INTO `source_usage` (`source_id`,`section_id`,`usage_type`,`claim_summary`,`exact_location`,`is_first_mention`,`citation_checked`,`notes`,`created_revision_id`) VALUES (@source_65_id,@section_id,'first_citation','Zusammenhang von Symmetriegruppen und Erhaltungssätzen.','Symmetrieabschnitt 3.2.4',1,1,'Neufassung 3.2.4 V2.',@revision_id);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.1',@section_id,'Innere binäre Verknüpfung','Eine innere binäre Verknüpfung auf A ordnet jedem Paar aus A×A eindeutig ein Element aus A zu.','\star:A\times A\longrightarrow A','\star:A\times A\longrightarrow A','literature',@source_63_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.2',@section_id,'Magma','Ein Magma ist eine nichtleere Menge mit einer abgeschlossenen inneren binären Verknüpfung.','\left(A,\star\right)','\left(A,\star\right)','literature',@source_63_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.3',@section_id,'Halbgruppe','Eine Halbgruppe ist ein Magma mit assoziativer Verknüpfung.','\left(A,\star\right)','\left(A,\star\right)','literature',@source_63_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.4',@section_id,'Neutrales Element','Ein neutrales Element lässt jedes Element bei links- und rechtsseitiger Verknüpfung unverändert.','e\star a=a\star e=a','e\star a=a\star e=a','literature',@source_63_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.5',@section_id,'Monoid','Ein Monoid ist eine Halbgruppe mit neutralem Element.','\left(A,\star,e\right)','\left(A,\star,e\right)','literature',@source_63_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.6',@section_id,'Gruppe','Eine Gruppe ist ein Monoid, in dem jedes Element ein inverses Element besitzt.','\left(A,\star\right)','\left(A,\star\right)','literature',@source_64_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.7',@section_id,'Abelsche Gruppe','Eine abelsche Gruppe ist eine Gruppe mit kommutativer Verknüpfung.','a\star b=b\star a','a\star b=b\star a','literature',@source_64_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.8',@section_id,'Untergruppe','Eine Untergruppe ist eine Teilmenge einer Gruppe, die bezüglich derselben Verknüpfung selbst eine Gruppe bildet.','H\subseteq G','H\subseteq G','literature',@source_64_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.9',@section_id,'Homomorphismus','Ein Homomorphismus ist eine Abbildung, die die algebraische Verknüpfung erhält.','\varphi(a\star b)=\varphi(a)\circ\varphi(b)','\varphi(a\star b)=\varphi(a)\circ\varphi(b)','literature',@source_64_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.10',@section_id,'Isomorphismus','Ein Isomorphismus ist ein bijektiver Homomorphismus.','G\cong H','G\cong H','literature',@source_64_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.11',@section_id,'Ring','Ein Ring ist eine Menge mit additiver abelscher Gruppenstruktur und einer assoziativen Multiplikation, die distributiv miteinander verknüpft sind.','\left(R,+,\cdot\right)','\left(R,+,\cdot\right)','literature',@source_62_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.12',@section_id,'Körper','Ein Körper ist ein kommutativer Ring mit Eins, in dem jedes von null verschiedene Element multiplikativ invertierbar ist.',NULL,NULL,'literature',@source_63_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `definitions` (`definition_number`,`section_id`,`title`,`definition_text`,`formal_latex`,`word_latex`,`provenance`,`source_id`,`validation_status`,`created_revision_id`) VALUES ('Def. 3.2.4.13',@section_id,'Vektorraum','Ein Vektorraum über K ist eine abelsche Gruppe mit kompatibler Skalarmultiplikation.','K\times V\longrightarrow V','K\times V\longrightarrow V','literature',@source_63_id,'checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `definition_id`=LAST_INSERT_ID(`definition_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `definition_text`=VALUES(`definition_text`),
  `formal_latex`=VALUES(`formal_latex`),
  `word_latex`=VALUES(`word_latex`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `assumptions`=VALUES(`assumptions`),
  `notes`=VALUES(`notes`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.65',@section_id,'Innere binäre Verknüpfung','\star:A\times A\longrightarrow A','\star:A\times A\longrightarrow A','Eine innere Verknüpfung bildet Paare aus A wieder nach A ab.','definition','literature',@source_63_id,NULL,'A ist eine nichtleere Menge.','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.66',@section_id,'Abgeschlossenheit','\forall a,b\in A:\;a\star b\in A','\forall a,b\in A:\;a\star b\in A','Das Ergebnis der Verknüpfung liegt wieder in A.','definition','literature',@source_63_id,NULL,'a,b liegen in A.','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.67',@section_id,'Magma','\left(A,\star\right)','\left(A,\star\right)','Paar aus Trägermenge und innerer Verknüpfung.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.68',@section_id,'Linke Klammerung','\left(a\star b\right)\star c','\left(a\star b\right)\star c','Erste Klammerung einer dreifachen Verknüpfung.','other','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.69',@section_id,'Rechte Klammerung','a\star\left(b\star c\right)','a\star\left(b\star c\right)','Zweite Klammerung einer dreifachen Verknüpfung.','other','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.70',@section_id,'Assoziativität','\forall a,b,c\in A:\;\left(a\star b\right)\star c=a\star\left(b\star c\right)','\forall a,b,c\in A:\;\left(a\star b\right)\star c=a\star\left(b\star c\right)','Assoziativgesetz.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.71',@section_id,'Halbgruppe','\left(A,\star\right)\text{ ist Halbgruppe}\Longleftrightarrow\star\text{ ist abgeschlossen und assoziativ}','\left(A,\star\right)\text{ ist Halbgruppe}\Longleftrightarrow\star\text{ ist abgeschlossen und assoziativ}','Charakterisierung einer Halbgruppe.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.72',@section_id,'Verknüpfungsfolge','a_1\star a_2\star\cdots\star a_n','a_1\star a_2\star\cdots\star a_n','Assoziativ interpretierbare endliche Verknüpfungsfolge.','schema','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.73',@section_id,'Linksneutrales Element','\forall a\in A:\;e\star a=a','\forall a\in A:\;e\star a=a','Linke Neutralität.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.74',@section_id,'Rechtsneutrales Element','\forall a\in A:\;a\star e=a','\forall a\in A:\;a\star e=a','Rechte Neutralität.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.75',@section_id,'Eindeutigkeit des neutralen Elements','e_1=e_1\star e_2=e_2','e_1=e_1\star e_2=e_2','Nachweis der Eindeutigkeit eines neutralen Elements.','derived','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.76',@section_id,'Monoid','\left(A,\star,e\right)\text{ ist Monoid}\Longleftrightarrow\left\{\begin{array}{l}\star\text{ ist assoziativ}\\e\text{ ist neutrales Element}\end{array}\right.','\left(A,\star,e\right)\text{ ist Monoid}\Longleftrightarrow\left\{\begin{array}{l}\star\text{ ist assoziativ}\\e\text{ ist neutrales Element}\end{array}\right.','Charakterisierung eines Monoids.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.77',@section_id,'Positive Potenz','a^n=\underbrace{a\star a\star\cdots\star a}_{n\text{ Faktoren}}','a^n=\underbrace{a\star a\star\cdots\star a}_{n\text{ Faktoren}}','Wiederholte Verknüpfung eines Elements.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.78',@section_id,'Nullte Potenz','a^0=e','a^0=e','Die nullte Potenz entspricht dem neutralen Element.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.79',@section_id,'Freies Wortmonoid','\left(\Sigma^\ast,\cdot,\varepsilon\right)','\left(\Sigma^\ast,\cdot,\varepsilon\right)','Monoid endlicher Wörter unter Konkatenation.','model','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.80',@section_id,'Rechtsinverses','a\star a^{-1}=e','a\star a^{-1}=e','Rechtsseitige Inversenbedingung.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.81',@section_id,'Linksinverses','a^{-1}\star a=e','a^{-1}\star a=e','Linksseitige Inversenbedingung.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.82',@section_id,'Gruppe','\left(A,\star\right)\text{ ist Gruppe}\Longleftrightarrow\left\{\begin{array}{l}\star\text{ ist assoziativ}\\e\text{ existiert}\\\forall a\in A\;\exists a^{-1}\in A\end{array}\right.','\left(A,\star\right)\text{ ist Gruppe}\Longleftrightarrow\left\{\begin{array}{l}\star\text{ ist assoziativ}\\e\text{ existiert}\\\forall a\in A\;\exists a^{-1}\in A\end{array}\right.','Charakterisierung einer Gruppe.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.83',@section_id,'Eindeutigkeit inverser Elemente','b=b\star e=b\star\left(a\star c\right)=\left(b\star a\right)\star c=e\star c=c','b=b\star e=b\star\left(a\star c\right)=\left(b\star a\right)\star c=e\star c=c','Herleitung der Eindeutigkeit des Inversen.','derived','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.84',@section_id,'Kommutativität','\forall a,b\in A:\;a\star b=b\star a','\forall a,b\in A:\;a\star b=b\star a','Kommutativgesetz einer abelschen Gruppe.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.85',@section_id,'Untergruppenkriterium','\forall a,b\in H:\;a\star b^{-1}\in H','\forall a,b\in H:\;a\star b^{-1}\in H','Praktisches Kriterium für eine Untergruppe.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.86',@section_id,'Gruppenhomomorphismus','\varphi\left(a\star b\right)=\varphi(a)\circ\varphi(b)','\varphi\left(a\star b\right)=\varphi(a)\circ\varphi(b)','Erhaltung der Gruppenverknüpfung.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.87',@section_id,'Isomorphie','G\cong H','G\cong H','Kennzeichnung strukturgleicher Gruppen.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.88',@section_id,'Ringstruktur','\left(R,+,\cdot\right)','\left(R,+,\cdot\right)','Ring mit zwei inneren Operationen.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.89',@section_id,'Assoziativität der Addition','\forall a,b,c\in R:\;\left(a+b\right)+c=a+\left(b+c\right)','\forall a,b,c\in R:\;\left(a+b\right)+c=a+\left(b+c\right)','Assoziativgesetz der Addition.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.90',@section_id,'Additives neutrales Element','a+0=a','a+0=a','Additive Neutralität.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.91',@section_id,'Additives Inverses','a+\left(-a\right)=0','a+\left(-a\right)=0','Additive Inversenbedingung.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.92',@section_id,'Assoziativität der Multiplikation','\left(a\cdot b\right)\cdot c=a\cdot\left(b\cdot c\right)','\left(a\cdot b\right)\cdot c=a\cdot\left(b\cdot c\right)','Assoziativgesetz der Multiplikation.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.93',@section_id,'Linkes Distributivgesetz','a\cdot\left(b+c\right)=a\cdot b+a\cdot c','a\cdot\left(b+c\right)=a\cdot b+a\cdot c','Linke Distributivität.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.94',@section_id,'Rechtes Distributivgesetz','\left(a+b\right)\cdot c=a\cdot c+b\cdot c','\left(a+b\right)\cdot c=a\cdot c+b\cdot c','Rechte Distributivität.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.95',@section_id,'Kommutative Multiplikation','a\cdot b=b\cdot a','a\cdot b=b\cdot a','Kommutativität in einem kommutativen Ring.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.96',@section_id,'Multiplikatives neutrales Element','1\cdot a=a=a\cdot 1','1\cdot a=a=a\cdot 1','Multiplikative Neutralität.','definition','literature',@source_62_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.97',@section_id,'Multiplikatives Inverses im Körper','\forall a\neq0\;\exists a^{-1}:\;a\cdot a^{-1}=1','\forall a\neq0\;\exists a^{-1}:\;a\cdot a^{-1}=1','Inverseigenschaft von Körperelementen.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.98',@section_id,'Grundkörper','\mathbb{Q},\;\mathbb{R},\;\mathbb{C}','\mathbb{Q},\;\mathbb{R},\;\mathbb{C}','Beispiele wichtiger Körper.','schema','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.99',@section_id,'Skalarmultiplikation','K\times V\longrightarrow V','K\times V\longrightarrow V','Skalarmultiplikation eines Vektorraums.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.100',@section_id,'Distributivität über Vektoraddition','\lambda\left(u+v\right)=\lambda u+\lambda v','\lambda\left(u+v\right)=\lambda u+\lambda v','Erstes Distributivgesetz des Vektorraums.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.101',@section_id,'Distributivität über Skalaraddition','\left(\lambda+\mu\right)v=\lambda v+\mu v','\left(\lambda+\mu\right)v=\lambda v+\mu v','Zweites Distributivgesetz des Vektorraums.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.102',@section_id,'Assoziativität der Skalarmultiplikation','\left(\lambda\mu\right)v=\lambda\left(\mu v\right)','\left(\lambda\mu\right)v=\lambda\left(\mu v\right)','Verträglichkeit der Skalarmultiplikation.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.103',@section_id,'Skalare Identität','1v=v','1v=v','Wirkung der skalaren Eins.','definition','literature',@source_63_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.104',@section_id,'Homomorphismus','\varphi\left(a\star b\right)=\varphi(a)\star\varphi(b)','\varphi\left(a\star b\right)=\varphi(a)\star\varphi(b)','Allgemeine Erhaltung einer algebraischen Verknüpfung.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.105',@section_id,'Additive Strukturerhaltung','\varphi\left(a+b\right)=\varphi(a)+\varphi(b)','\varphi\left(a+b\right)=\varphi(a)+\varphi(b)','Erhaltung der Ringaddition.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
INSERT INTO `equations` (`equation_number`,`section_id`,`title`,`equation_latex`,`word_latex`,`plain_description`,`equation_type`,`provenance`,`source_id`,`derivation`,`assumptions`,`validation_status`,`created_revision_id`) VALUES ('3.106',@section_id,'Multiplikative Strukturerhaltung','\varphi\left(a\cdot b\right)=\varphi(a)\cdot\varphi(b)','\varphi\left(a\cdot b\right)=\varphi(a)\cdot\varphi(b)','Erhaltung der Ringmultiplikation.','definition','literature',@source_64_id,NULL,'','checked',@revision_id)
ON DUPLICATE KEY UPDATE
  `equation_id`=LAST_INSERT_ID(`equation_id`),
  `section_id`=VALUES(`section_id`),
  `title`=VALUES(`title`),
  `equation_latex`=VALUES(`equation_latex`),
  `word_latex`=VALUES(`word_latex`),
  `plain_description`=VALUES(`plain_description`),
  `equation_type`=VALUES(`equation_type`),
  `provenance`=VALUES(`provenance`),
  `source_id`=VALUES(`source_id`),
  `derivation`=VALUES(`derivation`),
  `assumptions`=VALUES(`assumptions`),
  `validation_status`=VALUES(`validation_status`),
  `created_revision_id`=VALUES(`created_revision_id`);
SET @eq_65:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.65' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_65,'\star','binäre Verknüpfung','Innere Verknüpfung auf A.','A×A→A',1)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_65,'A','Trägermenge','Grundmenge der algebraischen Struktur.','Menge',2)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
SET @eq_73:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.73' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_73,'e','neutrales Element','Element ohne verändernde Wirkung.','A',1)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
SET @eq_80:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.80' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_80,'a^{-1}','inverses Element','Inverse zu a.','A',1)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
SET @eq_86:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.86' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_86,'\varphi','Homomorphismus','Strukturerhaltende Abbildung.','Abbildung',1)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
SET @eq_88:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.88' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_88,'R','Ring','Trägermenge des Ringes.','Ring',1)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
SET @eq_99:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.99' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_99,'K','Skalarkörper','Körper der Skalare.','Körper',1)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_99,'V','Vektorraum','Träger der Vektoren.','Vektorraum',2)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
SET @eq_100:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.100' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_100,'\lambda','Skalar','Element des Körpers K.','K',1)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_100,'u','Vektor','Element von V.','V',2)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
INSERT INTO `equation_symbols` (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,`domain_text`,`symbol_order`) VALUES (@eq_100,'v','Vektor','Element von V.','V',3)
ON DUPLICATE KEY UPDATE
  `symbol_name`=VALUES(`symbol_name`),
  `definition_text`=VALUES(`definition_text`),
  `unit_text`=VALUES(`unit_text`),
  `domain_text`=VALUES(`domain_text`),
  `symbol_order`=VALUES(`symbol_order`);
SET @first_eq:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.65' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `symbols` (`symbol_latex`,`symbol_word_latex`,`symbol_name`,`definition_text`,`scope_type`,`first_section_id`,`first_equation_id`,`unit_text`,`domain_text`,`codomain_text`,`is_vector`,`is_matrix`,`is_operator`,`notes`,`validation_status`,`created_revision_id`) VALUES ('\star','\star','binäre Verknüpfung','Abgeschlossene innere binäre Verknüpfung.','section',@section_id,@first_eq,NULL,'A×A','A',0,0,0,'Neufassung 3.2.4 V2.','checked',@revision_id) ON DUPLICATE KEY UPDATE `symbol_word_latex`=VALUES(`symbol_word_latex`),`symbol_name`=VALUES(`symbol_name`),`definition_text`=VALUES(`definition_text`),`first_section_id`=VALUES(`first_section_id`),`first_equation_id`=VALUES(`first_equation_id`),`domain_text`=VALUES(`domain_text`),`codomain_text`=VALUES(`codomain_text`),`is_vector`=VALUES(`is_vector`),`notes`=VALUES(`notes`),`validation_status`=VALUES(`validation_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @first_eq:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.73' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `symbols` (`symbol_latex`,`symbol_word_latex`,`symbol_name`,`definition_text`,`scope_type`,`first_section_id`,`first_equation_id`,`unit_text`,`domain_text`,`codomain_text`,`is_vector`,`is_matrix`,`is_operator`,`notes`,`validation_status`,`created_revision_id`) VALUES ('e','e','neutrales Element','Element, das unter der Verknüpfung keine Änderung bewirkt.','section',@section_id,@first_eq,NULL,'A','A',0,0,0,'Neufassung 3.2.4 V2.','checked',@revision_id) ON DUPLICATE KEY UPDATE `symbol_word_latex`=VALUES(`symbol_word_latex`),`symbol_name`=VALUES(`symbol_name`),`definition_text`=VALUES(`definition_text`),`first_section_id`=VALUES(`first_section_id`),`first_equation_id`=VALUES(`first_equation_id`),`domain_text`=VALUES(`domain_text`),`codomain_text`=VALUES(`codomain_text`),`is_vector`=VALUES(`is_vector`),`notes`=VALUES(`notes`),`validation_status`=VALUES(`validation_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @first_eq:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.80' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `symbols` (`symbol_latex`,`symbol_word_latex`,`symbol_name`,`definition_text`,`scope_type`,`first_section_id`,`first_equation_id`,`unit_text`,`domain_text`,`codomain_text`,`is_vector`,`is_matrix`,`is_operator`,`notes`,`validation_status`,`created_revision_id`) VALUES ('a^{-1}','a^{-1}','inverses Element','Inverse zu a bezüglich der Gruppenverknüpfung.','section',@section_id,@first_eq,NULL,'A','A',0,0,0,'Neufassung 3.2.4 V2.','checked',@revision_id) ON DUPLICATE KEY UPDATE `symbol_word_latex`=VALUES(`symbol_word_latex`),`symbol_name`=VALUES(`symbol_name`),`definition_text`=VALUES(`definition_text`),`first_section_id`=VALUES(`first_section_id`),`first_equation_id`=VALUES(`first_equation_id`),`domain_text`=VALUES(`domain_text`),`codomain_text`=VALUES(`codomain_text`),`is_vector`=VALUES(`is_vector`),`notes`=VALUES(`notes`),`validation_status`=VALUES(`validation_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @first_eq:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.86' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `symbols` (`symbol_latex`,`symbol_word_latex`,`symbol_name`,`definition_text`,`scope_type`,`first_section_id`,`first_equation_id`,`unit_text`,`domain_text`,`codomain_text`,`is_vector`,`is_matrix`,`is_operator`,`notes`,`validation_status`,`created_revision_id`) VALUES ('\varphi','\varphi','Homomorphismus','Strukturerhaltende Abbildung zwischen algebraischen Strukturen.','section',@section_id,@first_eq,NULL,NULL,NULL,0,0,0,'Neufassung 3.2.4 V2.','checked',@revision_id) ON DUPLICATE KEY UPDATE `symbol_word_latex`=VALUES(`symbol_word_latex`),`symbol_name`=VALUES(`symbol_name`),`definition_text`=VALUES(`definition_text`),`first_section_id`=VALUES(`first_section_id`),`first_equation_id`=VALUES(`first_equation_id`),`domain_text`=VALUES(`domain_text`),`codomain_text`=VALUES(`codomain_text`),`is_vector`=VALUES(`is_vector`),`notes`=VALUES(`notes`),`validation_status`=VALUES(`validation_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @first_eq:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.88' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `symbols` (`symbol_latex`,`symbol_word_latex`,`symbol_name`,`definition_text`,`scope_type`,`first_section_id`,`first_equation_id`,`unit_text`,`domain_text`,`codomain_text`,`is_vector`,`is_matrix`,`is_operator`,`notes`,`validation_status`,`created_revision_id`) VALUES ('R','R','Ring','Trägermenge mit additiver und multiplikativer Verknüpfung.','section',@section_id,@first_eq,NULL,'Ring',NULL,0,0,0,'Neufassung 3.2.4 V2.','checked',@revision_id) ON DUPLICATE KEY UPDATE `symbol_word_latex`=VALUES(`symbol_word_latex`),`symbol_name`=VALUES(`symbol_name`),`definition_text`=VALUES(`definition_text`),`first_section_id`=VALUES(`first_section_id`),`first_equation_id`=VALUES(`first_equation_id`),`domain_text`=VALUES(`domain_text`),`codomain_text`=VALUES(`codomain_text`),`is_vector`=VALUES(`is_vector`),`notes`=VALUES(`notes`),`validation_status`=VALUES(`validation_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @first_eq:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.99' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `symbols` (`symbol_latex`,`symbol_word_latex`,`symbol_name`,`definition_text`,`scope_type`,`first_section_id`,`first_equation_id`,`unit_text`,`domain_text`,`codomain_text`,`is_vector`,`is_matrix`,`is_operator`,`notes`,`validation_status`,`created_revision_id`) VALUES ('K','K','Skalarkörper','Körper der Skalare eines Vektorraums.','section',@section_id,@first_eq,NULL,'Körper',NULL,0,0,0,'Neufassung 3.2.4 V2.','checked',@revision_id) ON DUPLICATE KEY UPDATE `symbol_word_latex`=VALUES(`symbol_word_latex`),`symbol_name`=VALUES(`symbol_name`),`definition_text`=VALUES(`definition_text`),`first_section_id`=VALUES(`first_section_id`),`first_equation_id`=VALUES(`first_equation_id`),`domain_text`=VALUES(`domain_text`),`codomain_text`=VALUES(`codomain_text`),`is_vector`=VALUES(`is_vector`),`notes`=VALUES(`notes`),`validation_status`=VALUES(`validation_status`),`created_revision_id`=VALUES(`created_revision_id`);
SET @first_eq:=(SELECT `equation_id` FROM `equations` WHERE `equation_number`='3.99' AND `section_id`=@section_id LIMIT 1);
INSERT INTO `symbols` (`symbol_latex`,`symbol_word_latex`,`symbol_name`,`definition_text`,`scope_type`,`first_section_id`,`first_equation_id`,`unit_text`,`domain_text`,`codomain_text`,`is_vector`,`is_matrix`,`is_operator`,`notes`,`validation_status`,`created_revision_id`) VALUES ('V','V','Vektorraum','Vektorraum über dem Körper K.','section',@section_id,@first_eq,NULL,'Vektorraum',NULL,1,0,0,'Neufassung 3.2.4 V2.','checked',@revision_id) ON DUPLICATE KEY UPDATE `symbol_word_latex`=VALUES(`symbol_word_latex`),`symbol_name`=VALUES(`symbol_name`),`definition_text`=VALUES(`definition_text`),`first_section_id`=VALUES(`first_section_id`),`first_equation_id`=VALUES(`first_equation_id`),`domain_text`=VALUES(`domain_text`),`codomain_text`=VALUES(`codomain_text`),`is_vector`=VALUES(`is_vector`),`notes`=VALUES(`notes`),`validation_status`=VALUES(`validation_status`),`created_revision_id`=VALUES(`created_revision_id`);
DELETE FROM `section_change_log` WHERE `revision_id`=@revision_id AND `section_id`=@section_id;
INSERT INTO `section_change_log` (`revision_id`,`section_id`,`change_type`,`object_type`,`object_reference`,`change_summary`,`previous_value`,`new_value`) VALUES (@revision_id,@section_id,'rewritten','section','3.2.4','Abschnitt 3.2.4 vollständig neu gefasst.','Bisheriger Repository-Stand.','Neufassung mit fünf neuen Quellen, dreizehn Definitionen und 42 Gleichungen.');
INSERT INTO `section_change_log` (`revision_id`,`section_id`,`change_type`,`object_type`,`object_reference`,`change_summary`,`previous_value`,`new_value`) VALUES (@revision_id,@section_id,'source_added','sources','[61]–[65]','Fünf neue Literaturquellen registriert.',NULL,'Galois [61], Noether [62], van der Waerden [63], Mac Lane/Birkhoff [64], Noether [65].');
INSERT INTO `section_change_log` (`revision_id`,`section_id`,`change_type`,`object_type`,`object_reference`,`change_summary`,`previous_value`,`new_value`) VALUES (@revision_id,@section_id,'definition_added','definitions','Def. 3.2.4.1–Def. 3.2.4.13','Dreizehn algebraische Definitionen registriert.',NULL,'Binäre Verknüpfung bis Vektorraum.');
INSERT INTO `section_change_log` (`revision_id`,`section_id`,`change_type`,`object_type`,`object_reference`,`change_summary`,`previous_value`,`new_value`) VALUES (@revision_id,@section_id,'equation_added','equations','(3.65)–(3.106)','42 Gleichungen registriert.',NULL,'Algebraische Strukturen und Strukturerhaltung.');
INSERT INTO `section_change_log` (`revision_id`,`section_id`,`change_type`,`object_type`,`object_reference`,`change_summary`,`previous_value`,`new_value`) VALUES (@revision_id,@section_id,'symbol_added','symbols','\star, e, a^{-1}, \varphi, R, K, V','Zentrale Abschnittssymbole registriert.',NULL,'Symbolregister 3.2.4 V2.');
INSERT INTO `repository_counters` (`counter_key`,`counter_value`) VALUES ('next_citation_number','66'),('next_equation_number','3.107'),('last_edited_section','3.2.4'),('last_repository_revision','RKB-2026-07-14-K3.2.4-NEUFASSUNG-V2') ON DUPLICATE KEY UPDATE `counter_value`=VALUES(`counter_value`);
COMMIT;

/* Kontrollabfragen */
SELECT `revision_code`,`scope_reference`,`version_label`,`parent_revision_id` FROM `repository_revisions` WHERE `revision_id`=@revision_id;
SELECT `section_code`,`title`,`status`,`is_original_contribution`,`notes` FROM `dissertation_sections` WHERE `section_id`=@section_id;
SELECT s.`citation_number`,s.`source_key`,s.`title`,s.`verification_status` FROM `sources` s WHERE s.`citation_number` BETWEEN 61 AND 65 ORDER BY s.`citation_number`;
SELECT COUNT(*) AS `source_usages`,SUM(`is_first_mention`) AS `first_mentions` FROM `source_usage` WHERE `section_id`=@section_id;
SELECT `definition_number`,`title`,`validation_status` FROM `definitions` WHERE `section_id`=@section_id ORDER BY CAST(SUBSTRING_INDEX(`definition_number`,'.',-1) AS UNSIGNED);
SELECT `equation_number`,`title`,`equation_type`,`word_latex`,`validation_status` FROM `equations` WHERE `section_id`=@section_id ORDER BY CAST(SUBSTRING_INDEX(`equation_number`,'.',-1) AS UNSIGNED);
SELECT COUNT(*) AS `equation_count` FROM `equations` WHERE `section_id`=@section_id;
SELECT COUNT(*) AS `orphan_equation_symbols` FROM `equation_symbols` es LEFT JOIN `equations` e ON e.`equation_id`=es.`equation_id` WHERE e.`equation_id` IS NULL;
SELECT `counter_key`,`counter_value` FROM `repository_counters` WHERE `counter_key` IN ('next_citation_number','next_equation_number','last_edited_section','last_repository_revision') ORDER BY `counter_key`;
SELECT COUNT(*) AS `invalid_equation_types` FROM `equations` WHERE `section_id`=@section_id AND `equation_type` NOT IN ('definition','axiom','theorem','lemma','derived','schema','model','metric','other');
