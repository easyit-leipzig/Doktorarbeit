# Beispielhafte Akteur-Funktion basierend auf Kapitel 3
import numpy as np
import matplotlib.pyplot as plt

size = 100
steps = 50
psi = np.random.normal(0.0, 0.05, (size, size))
psi += np.exp(-((np.arange(size) - 70)[:, None]**2 + (np.arange(size) - 30)**2)/200)

agent = {"x": size // 2, "y": size // 2, "log": []}

def evaluate(psi, x, y):
    scores = []
    positions = []
    for dx in [-1, 0, 1]:
        for dy in [-1, 0, 1]:
            nx, ny = x + dx, y + dy
            if 0 <= nx < size and 0 <= ny < size:
                score = psi[nx, ny]
                scores.append(score)
                positions.append((nx, ny))
    return positions[np.argmax(scores)]

def act(psi, x, y):
    psi[x, y] += 0.5
    return psi

for t in range(steps):
    new_x, new_y = evaluate(psi, agent["x"], agent["y"])
    agent["x"], agent["y"] = new_x, new_y
    psi = act(psi, new_x, new_y)
    agent["log"].append((new_x, new_y))
    psi += 0.1 * (np.roll(psi, 1, axis=0) + np.roll(psi, -1, axis=0) +
                  np.roll(psi, 1, axis=1) + np.roll(psi, -1, axis=1) - 4 * psi)

plt.figure(figsize=(6, 6))
plt.imshow(psi, cmap='viridis', origin='lower')
log = np.array(agent["log"])
plt.plot(log[:,1], log[:,0], color='red', linewidth=2, label='Agentenpfad')
plt.scatter([log[0,1]], [log[0,0]], color='blue', label='Start')
plt.scatter([log[-1,1]], [log[-1,0]], color='white', label='Ende')
plt.title("Funktionales Feld Ψ mit intentionalem Agenten")
plt.xlabel("x")
plt.ylabel("y")
plt.colorbar(label='Ψ(x,y)')
plt.legend()
plt.tight_layout()
plt.show()
