USE `frzk_rkb`;
SET NAMES utf8mb4;

DELIMITER $$

DROP PROCEDURE IF EXISTS `repo_begin_revision`$$
CREATE PROCEDURE `repo_begin_revision`(
    IN p_revision_code VARCHAR(100),
    IN p_scope_type VARCHAR(50),
    IN p_scope_reference VARCHAR(255),
    IN p_version_label VARCHAR(100),
    IN p_summary TEXT,
    IN p_created_by VARCHAR(255),
    IN p_parent_revision_code VARCHAR(100),
    OUT p_revision_id BIGINT UNSIGNED
)
BEGIN
    DECLARE v_parent_id BIGINT UNSIGNED DEFAULT NULL;

    IF p_parent_revision_code IS NOT NULL AND p_parent_revision_code <> '' THEN
        SELECT `revision_id` INTO v_parent_id
        FROM `repository_revisions`
        WHERE `revision_code` = p_parent_revision_code
        LIMIT 1;
    END IF;

    INSERT INTO `repository_revisions`
        (`revision_code`,`revision_date`,`scope_type`,`scope_reference`,
         `version_label`,`summary`,`created_by`,`parent_revision_id`)
    VALUES
        (p_revision_code,NOW(),p_scope_type,p_scope_reference,
         p_version_label,p_summary,p_created_by,v_parent_id)
    ON DUPLICATE KEY UPDATE
        `revision_id` = LAST_INSERT_ID(`revision_id`),
        `revision_date` = VALUES(`revision_date`),
        `scope_type` = VALUES(`scope_type`),
        `scope_reference` = VALUES(`scope_reference`),
        `version_label` = VALUES(`version_label`),
        `summary` = VALUES(`summary`),
        `created_by` = VALUES(`created_by`),
        `parent_revision_id` = VALUES(`parent_revision_id`);

    SET p_revision_id = LAST_INSERT_ID();
END$$

DROP PROCEDURE IF EXISTS `repo_set_counter`$$
CREATE PROCEDURE `repo_set_counter`(
    IN p_counter_key VARCHAR(100),
    IN p_counter_value VARCHAR(100)
)
BEGIN
    INSERT INTO `repository_counters` (`counter_key`,`counter_value`)
    VALUES (p_counter_key,p_counter_value)
    ON DUPLICATE KEY UPDATE `counter_value`=VALUES(`counter_value`);
END$$

DROP PROCEDURE IF EXISTS `repo_upsert_equation_symbol`$$
CREATE PROCEDURE `repo_upsert_equation_symbol`(
    IN p_equation_id BIGINT UNSIGNED,
    IN p_symbol_latex VARCHAR(255),
    IN p_symbol_name VARCHAR(255),
    IN p_definition_text TEXT,
    IN p_unit_text VARCHAR(255),
    IN p_domain_text VARCHAR(500),
    IN p_symbol_order SMALLINT UNSIGNED
)
BEGIN
    INSERT INTO `equation_symbols`
        (`equation_id`,`symbol_latex`,`symbol_name`,`definition_text`,
         `unit_text`,`domain_text`,`symbol_order`)
    VALUES
        (p_equation_id,p_symbol_latex,p_symbol_name,p_definition_text,
         p_unit_text,p_domain_text,p_symbol_order)
    ON DUPLICATE KEY UPDATE
        `symbol_name`=VALUES(`symbol_name`),
        `definition_text`=VALUES(`definition_text`),
        `unit_text`=VALUES(`unit_text`),
        `domain_text`=VALUES(`domain_text`),
        `symbol_order`=VALUES(`symbol_order`);
END$$

DROP PROCEDURE IF EXISTS `repo_assert_section_exists`$$
CREATE PROCEDURE `repo_assert_section_exists`(
    IN p_section_code VARCHAR(50),
    OUT p_section_id BIGINT UNSIGNED
)
BEGIN
    SET p_section_id = NULL;
    SELECT `section_id` INTO p_section_id
    FROM `dissertation_sections`
    WHERE `section_code`=p_section_code
    LIMIT 1;

    IF p_section_id IS NULL THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT='Repositoryfehler: dissertation_sections enthält den angeforderten Abschnitt nicht.';
    END IF;
END$$

DELIMITER ;
