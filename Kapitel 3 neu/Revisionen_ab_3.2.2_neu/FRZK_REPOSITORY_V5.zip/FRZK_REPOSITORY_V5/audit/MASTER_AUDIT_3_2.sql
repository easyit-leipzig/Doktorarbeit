USE `frzk_rkb`;
SET NAMES utf8mb4;

SELECT 'REVISION_CHAIN' AS audit_block;
SELECT r.revision_id,r.revision_code,r.scope_reference,r.parent_revision_id,p.revision_code AS parent_code
FROM repository_revisions r
LEFT JOIN repository_revisions p ON p.revision_id=r.parent_revision_id
WHERE r.scope_reference IN ('3.2.1','3.2.2','3.2.3','3.2.4','3.2.5','3.2.6')
ORDER BY r.revision_id;

SELECT 'SECTION_STATUS' AS audit_block;
SELECT section_code,title,status,is_original_contribution
FROM dissertation_sections
WHERE section_code BETWEEN '3.2.1' AND '3.2.6'
ORDER BY section_code;

SELECT 'EQUATION_COUNTS' AS audit_block;
SELECT ds.section_code,COUNT(e.equation_id) AS equation_count,
       MIN(CAST(SUBSTRING_INDEX(e.equation_number,'.',-1) AS UNSIGNED)) AS min_number,
       MAX(CAST(SUBSTRING_INDEX(e.equation_number,'.',-1) AS UNSIGNED)) AS max_number,
       SUM(e.word_latex IS NULL OR TRIM(e.word_latex)='') AS missing_word_latex
FROM dissertation_sections ds
LEFT JOIN equations e ON e.section_id=ds.section_id
WHERE ds.section_code BETWEEN '3.2.1' AND '3.2.6'
GROUP BY ds.section_id,ds.section_code
ORDER BY ds.section_code;

SELECT 'DUPLICATE_EQUATIONS' AS audit_block;
SELECT equation_number,COUNT(*) AS duplicate_count
FROM equations
GROUP BY equation_number
HAVING COUNT(*)>1;

SELECT 'DUPLICATE_EQUATION_SYMBOLS' AS audit_block;
SELECT equation_id,symbol_latex,COUNT(*) AS duplicate_count
FROM equation_symbols
GROUP BY equation_id,symbol_latex
HAVING COUNT(*)>1;

SELECT 'ORPHANS' AS audit_block;
SELECT 'equation_symbols_without_equation' AS orphan_type,COUNT(*) AS orphan_count
FROM equation_symbols es LEFT JOIN equations e ON e.equation_id=es.equation_id
WHERE e.equation_id IS NULL
UNION ALL
SELECT 'equations_without_section',COUNT(*)
FROM equations e LEFT JOIN dissertation_sections ds ON ds.section_id=e.section_id
WHERE ds.section_id IS NULL
UNION ALL
SELECT 'source_usage_without_source',COUNT(*)
FROM source_usage su LEFT JOIN sources s ON s.source_id=su.source_id
WHERE s.source_id IS NULL
UNION ALL
SELECT 'source_usage_without_section',COUNT(*)
FROM source_usage su LEFT JOIN dissertation_sections ds ON ds.section_id=su.section_id
WHERE ds.section_id IS NULL;

SELECT 'SOURCE_NUMBERING' AS audit_block;
SELECT citation_number,source_key,title
FROM sources
WHERE citation_number BETWEEN 58 AND 69
ORDER BY citation_number;

SELECT 'SOURCE_DUPLICATES' AS audit_block;
SELECT citation_number,COUNT(*) AS duplicate_count
FROM sources
GROUP BY citation_number
HAVING COUNT(*)>1;

SELECT 'COUNTERS' AS audit_block;
SELECT counter_key,counter_value
FROM repository_counters
WHERE counter_key IN ('next_citation_number','next_equation_number','last_edited_section','last_repository_revision')
ORDER BY counter_key;

SELECT 'EXPECTED_FINAL_STATE' AS audit_block;
SELECT
  (SELECT counter_value FROM repository_counters WHERE counter_key='last_edited_section')='3.2.6' AS last_section_ok,
  (SELECT counter_value FROM repository_counters WHERE counter_key='next_citation_number')='70' AS citation_counter_ok,
  (SELECT counter_value FROM repository_counters WHERE counter_key='next_equation_number')='3.159' AS equation_counter_ok,
  NOT EXISTS(SELECT 1 FROM equations GROUP BY equation_number HAVING COUNT(*)>1) AS equations_unique,
  NOT EXISTS(SELECT 1 FROM equation_symbols GROUP BY equation_id,symbol_latex HAVING COUNT(*)>1) AS equation_symbols_unique;
