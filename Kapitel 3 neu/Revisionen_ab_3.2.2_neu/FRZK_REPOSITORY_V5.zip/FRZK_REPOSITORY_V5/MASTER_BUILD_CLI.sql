/* FRZK Repository V5 master entry point for MySQL/MariaDB CLI. */
SOURCE 02_chapter_3_2/MASTER_3_2_CLI.sql;
