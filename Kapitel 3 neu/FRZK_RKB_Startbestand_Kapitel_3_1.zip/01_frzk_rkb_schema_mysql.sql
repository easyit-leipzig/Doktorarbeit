-- FRZK Research Knowledge Base (FRZK-RKB)
-- MySQL 8.0+ schema
-- Character set: utf8mb4
-- Initial scope: complete dissertation, seeded with chapter 3.1

CREATE DATABASE IF NOT EXISTS frzk_rkb
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE frzk_rkb;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP VIEW IF EXISTS v_chapter_bibliography;
DROP VIEW IF EXISTS v_citation_audit;
DROP VIEW IF EXISTS v_equation_register;
DROP TABLE IF EXISTS equation_symbols;
DROP TABLE IF EXISTS equations;
DROP TABLE IF EXISTS source_usage;
DROP TABLE IF EXISTS source_relations;
DROP TABLE IF EXISTS source_topics;
DROP TABLE IF EXISTS topics;
DROP TABLE IF EXISTS annotations;
DROP TABLE IF EXISTS source_authors;
DROP TABLE IF EXISTS authors;
DROP TABLE IF EXISTS sources;
DROP TABLE IF EXISTS dissertation_sections;
DROP TABLE IF EXISTS documents;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE documents (
    document_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(500) NOT NULL,
    file_name VARCHAR(500),
    document_type ENUM('dissertation','chapter','article','book','dataset','appendix','other') NOT NULL DEFAULT 'other',
    version_label VARCHAR(100),
    file_path VARCHAR(1000),
    checksum_sha256 CHAR(64),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_documents_file_version (file_name, version_label)
) ENGINE=InnoDB;

CREATE TABLE dissertation_sections (
    section_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    parent_section_id BIGINT UNSIGNED NULL,
    section_code VARCHAR(50) NOT NULL,
    title VARCHAR(500) NOT NULL,
    chapter_no INT NOT NULL,
    section_order DECIMAL(10,4) NOT NULL,
    status ENUM('planned','draft','review','final') NOT NULL DEFAULT 'planned',
    is_original_contribution BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    UNIQUE KEY uq_section_code (section_code),
    CONSTRAINT fk_sections_parent
        FOREIGN KEY (parent_section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE sources (
    source_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    citation_number INT UNSIGNED NULL,
    source_key VARCHAR(150) NOT NULL,
    source_type ENUM(
        'journal_article','book','book_chapter','conference_paper','thesis',
        'report','standard','website','historical_work','edited_volume','other'
    ) NOT NULL,
    title VARCHAR(1000) NOT NULL,
    subtitle VARCHAR(1000),
    year_original SMALLINT,
    year_edition SMALLINT,
    journal VARCHAR(500),
    publisher VARCHAR(500),
    place VARCHAR(255),
    volume VARCHAR(100),
    issue VARCHAR(100),
    pages VARCHAR(100),
    edition VARCHAR(100),
    doi VARCHAR(255),
    isbn VARCHAR(100),
    url VARCHAR(1500),
    language_code CHAR(2) DEFAULT 'de',
    priority TINYINT UNSIGNED NOT NULL DEFAULT 3,
    evidence_type ENUM('primary','secondary','review','textbook','historical','reference') NOT NULL DEFAULT 'secondary',
    frzk_relevance TINYINT UNSIGNED NOT NULL DEFAULT 0,
    verification_status ENUM('imported','partially_verified','verified','needs_review') NOT NULL DEFAULT 'imported',
    first_citation_section_code VARCHAR(50),
    first_citation_note TEXT,
    full_citation_text TEXT NOT NULL,
    short_citation_text VARCHAR(500),
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_sources_citation_number (citation_number),
    UNIQUE KEY uq_sources_source_key (source_key),
    KEY idx_sources_title (title(191)),
    KEY idx_sources_year (year_original),
    KEY idx_sources_priority (priority),
    KEY idx_sources_frzk_relevance (frzk_relevance)
) ENGINE=InnoDB;

CREATE TABLE authors (
    author_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    family_name VARCHAR(255) NOT NULL,
    given_names VARCHAR(255),
    normalized_name VARCHAR(500) NOT NULL,
    orcid VARCHAR(50),
    birth_year SMALLINT,
    death_year SMALLINT,
    notes TEXT,
    UNIQUE KEY uq_authors_normalized_name (normalized_name)
) ENGINE=InnoDB;

CREATE TABLE source_authors (
    source_id BIGINT UNSIGNED NOT NULL,
    author_id BIGINT UNSIGNED NOT NULL,
    author_order SMALLINT UNSIGNED NOT NULL,
    role ENUM('author','editor','translator') NOT NULL DEFAULT 'author',
    PRIMARY KEY (source_id, author_id, role),
    UNIQUE KEY uq_source_author_order (source_id, role, author_order),
    CONSTRAINT fk_source_authors_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_source_authors_author
        FOREIGN KEY (author_id) REFERENCES authors(author_id)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE annotations (
    annotation_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    source_id BIGINT UNSIGNED NOT NULL,
    contribution TEXT,
    significance_for_dissertation TEXT,
    citation_reason TEXT,
    adopted_claims TEXT,
    limitations TEXT,
    scientific_discussion TEXT,
    annotation_status ENUM('draft','reviewed','approved') NOT NULL DEFAULT 'draft',
    reviewed_at DATETIME,
    UNIQUE KEY uq_annotation_source (source_id),
    CONSTRAINT fk_annotations_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE topics (
    topic_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    parent_topic_id BIGINT UNSIGNED NULL,
    topic_code VARCHAR(100) NOT NULL,
    label VARCHAR(255) NOT NULL,
    description TEXT,
    UNIQUE KEY uq_topic_code (topic_code),
    CONSTRAINT fk_topics_parent
        FOREIGN KEY (parent_topic_id) REFERENCES topics(topic_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE source_topics (
    source_id BIGINT UNSIGNED NOT NULL,
    topic_id BIGINT UNSIGNED NOT NULL,
    relevance TINYINT UNSIGNED NOT NULL DEFAULT 3,
    PRIMARY KEY (source_id, topic_id),
    CONSTRAINT fk_source_topics_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_source_topics_topic
        FOREIGN KEY (topic_id) REFERENCES topics(topic_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE source_relations (
    relation_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    source_id_from BIGINT UNSIGNED NOT NULL,
    source_id_to BIGINT UNSIGNED NOT NULL,
    relation_type ENUM(
        'extends','criticizes','formalizes','applies','reviews',
        'historical_predecessor','alternative_to','supports','contradicts','related'
    ) NOT NULL,
    relation_note TEXT,
    UNIQUE KEY uq_source_relation (source_id_from, source_id_to, relation_type),
    CONSTRAINT fk_source_relations_from
        FOREIGN KEY (source_id_from) REFERENCES sources(source_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_source_relations_to
        FOREIGN KEY (source_id_to) REFERENCES sources(source_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE source_usage (
    usage_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    source_id BIGINT UNSIGNED NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    usage_type ENUM(
        'first_citation','background','definition','theorem','method',
        'historical_context','state_of_research','critique','research_gap',
        'comparison','equation_source','figure_source','table_source','other'
    ) NOT NULL,
    claim_summary TEXT NOT NULL,
    exact_location VARCHAR(255),
    is_first_mention BOOLEAN NOT NULL DEFAULT FALSE,
    citation_checked BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    KEY idx_usage_section (section_id),
    KEY idx_usage_source (source_id),
    CONSTRAINT fk_source_usage_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_source_usage_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE equations (
    equation_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    equation_number VARCHAR(50) NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(500),
    equation_latex TEXT NOT NULL,
    word_latex TEXT NOT NULL,
    plain_description TEXT NOT NULL,
    equation_type ENUM('definition','axiom','theorem','lemma','derived','schema','model','metric','other') NOT NULL DEFAULT 'other',
    provenance ENUM('original','adapted','literature') NOT NULL DEFAULT 'original',
    source_id BIGINT UNSIGNED NULL,
    derivation TEXT,
    assumptions TEXT,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    UNIQUE KEY uq_equation_number (equation_number),
    CONSTRAINT fk_equations_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_equations_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE equation_symbols (
    equation_symbol_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    equation_id BIGINT UNSIGNED NOT NULL,
    symbol_latex VARCHAR(255) NOT NULL,
    symbol_name VARCHAR(255) NOT NULL,
    definition_text TEXT NOT NULL,
    unit_text VARCHAR(255),
    domain_text VARCHAR(500),
    symbol_order SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    UNIQUE KEY uq_equation_symbol (equation_id, symbol_latex),
    CONSTRAINT fk_equation_symbols_equation
        FOREIGN KEY (equation_id) REFERENCES equations(equation_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE VIEW v_chapter_bibliography AS
SELECT DISTINCT
    ds.chapter_no,
    s.citation_number,
    s.full_citation_text,
    s.short_citation_text,
    s.priority,
    s.frzk_relevance,
    s.verification_status
FROM source_usage su
JOIN sources s ON s.source_id = su.source_id
JOIN dissertation_sections ds ON ds.section_id = su.section_id
WHERE s.citation_number IS NOT NULL
ORDER BY ds.chapter_no, s.citation_number;

CREATE VIEW v_citation_audit AS
SELECT
    s.citation_number,
    s.source_key,
    s.full_citation_text,
    s.verification_status,
    COUNT(su.usage_id) AS usage_count,
    SUM(CASE WHEN su.is_first_mention = TRUE THEN 1 ELSE 0 END) AS first_mention_count,
    MIN(ds.section_code) AS first_used_section
FROM sources s
LEFT JOIN source_usage su ON su.source_id = s.source_id
LEFT JOIN dissertation_sections ds ON ds.section_id = su.section_id
GROUP BY s.source_id, s.citation_number, s.source_key, s.full_citation_text, s.verification_status;

CREATE VIEW v_equation_register AS
SELECT
    e.equation_number,
    ds.section_code,
    ds.title AS section_title,
    e.title,
    e.word_latex,
    e.plain_description,
    e.provenance,
    s.citation_number AS source_citation_number,
    e.validation_status
FROM equations e
JOIN dissertation_sections ds ON ds.section_id = e.section_id
LEFT JOIN sources s ON s.source_id = e.source_id
ORDER BY
    CAST(SUBSTRING_INDEX(e.equation_number, '.', 1) AS UNSIGNED),
    CAST(SUBSTRING_INDEX(e.equation_number, '.', -1) AS UNSIGNED);
