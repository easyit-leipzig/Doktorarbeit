# Interaktive Jupyter-Demo: Strategievergleich für Akteur-Funktion
import numpy as np
import matplotlib.pyplot as plt
from ipywidgets import interact, IntSlider, Dropdown

def simulate_agent(strategy='max', diffusion=0.1, steps=40):
    size = 100
    psi = np.zeros((size, size))
    psi += np.exp(-((np.arange(size) - 70)[:, None]**2 + (np.arange(size) - 30)**2)/200)
    agent_x, agent_y = size // 2, size // 2
    path = [(agent_x, agent_y)]

    def evaluate(psi, x, y, strategy):
        positions = []
        scores = []
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                nx, ny = x + dx, y + dy
                if 0 <= nx < size and 0 <= ny < size:
                    positions.append((nx, ny))
                    scores.append(psi[nx, ny])
        if strategy == 'max':
            return positions[np.argmax(scores)]
        elif strategy == 'random':
            return positions[np.random.randint(len(positions))]
        elif strategy == 'softmax':
            scores_np = np.array(scores)
            shifted = scores_np - np.max(scores_np)
            exp_scores = np.exp(shifted)
            probs = exp_scores / np.sum(exp_scores)
            probs = np.clip(probs, 1e-10, 1.0)
            probs /= np.sum(probs)
            return positions[np.random.choice(len(positions), p=probs)]

    for t in range(steps):
        new_x, new_y = evaluate(psi, agent_x, agent_y, strategy)
        agent_x, agent_y = new_x, new_y
        psi[agent_x, agent_y] += 0.6
        psi += diffusion * (np.roll(psi, 1, axis=0) + np.roll(psi, -1, axis=0) +
                            np.roll(psi, 1, axis=1) + np.roll(psi, -1, axis=1) - 4 * psi)
        path.append((agent_x, agent_y))

    plt.figure(figsize=(6,6))
    plt.imshow(psi, cmap='viridis', origin='lower')
    path = np.array(path)
    plt.plot(path[:,1], path[:,0], color='red', lw=2, label='Agentenpfad')
    plt.scatter([path[0,1]], [path[0,0]], color='blue', label='Start')
    plt.scatter([path[-1,1]], [path[-1,0]], color='white', label='Ende')
    plt.title(f"Strategie: {strategy}, Diffusion: {diffusion}")
    plt.legend()
    plt.colorbar(label='Ψ(x,y)')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.tight_layout()
    plt.show()

interact(simulate_agent,
         strategy=Dropdown(options=['max', 'softmax', 'random'], value='max', description='Strategie:'),
         diffusion=IntSlider(min=0, max=30, step=5, value=10, description='Diffusion x0.01:'),
         steps=IntSlider(min=10, max=100, step=10, value=40, description='Zeitschritte:'))
