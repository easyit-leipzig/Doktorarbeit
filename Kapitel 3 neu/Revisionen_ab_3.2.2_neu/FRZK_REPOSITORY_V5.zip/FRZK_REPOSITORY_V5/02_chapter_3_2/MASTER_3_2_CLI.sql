/* MySQL/MariaDB command-line client only. Run from repository root. */
SOURCE 00_infrastructure/010_repository_procedures.sql;
SOURCE 02_chapter_3_2/migrations/3_2_1_V5.sql;
SOURCE 02_chapter_3_2/migrations/3_2_2_V5.sql;
SOURCE 02_chapter_3_2/migrations/3_2_3_V5.sql;
SOURCE 02_chapter_3_2/migrations/3_2_4_V5.sql;
SOURCE 02_chapter_3_2/migrations/3_2_5_V5.sql;
SOURCE 02_chapter_3_2/migrations/3_2_6_V5.sql;
SOURCE audit/MASTER_AUDIT_3_2.sql;
