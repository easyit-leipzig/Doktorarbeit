-- FRZK-RKB repository extension seed v2.0
USE frzk_rkb;
SET NAMES utf8mb4;

INSERT INTO repository_revisions
(revision_code,revision_date,scope_type,scope_reference,version_label,summary)
VALUES
('RKB-2026-07-11-V2','2026-07-11 16:00:00','repository','frzk_rkb','2.0',
 'Erweiterung der FRZK-RKB zu einem vollständigen Dissertations-Repository.');

-- Initial acronyms
INSERT INTO acronyms
(acronym,full_form,explanation,first_section_id,language_code,category,is_project_specific,validation_status,created_revision_id)
VALUES
('FRZK','Funktionales Raum-Zeit-Kohärenzsystem',
 'Zentrale, in dieser Dissertation entwickelte Theorie zur funktionalen Herleitung von Raum, Zeit und Kohärenz.',
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.1'),'de','Theorie',1,'checked',
 (SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2')),
('ZFC','Zermelo-Fraenkel-Mengenlehre mit Auswahlaxiom',
 'International verbreitete axiomatische Grundlage großer Teile der modernen Mathematik.',
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.2.1'),'de','Mathematik',0,'draft',
 (SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'));

-- Global symbols from the two existing equations
INSERT INTO symbols
(symbol_latex,symbol_word_latex,symbol_name,definition_text,scope_type,first_section_id,
 validation_status,created_revision_id)
VALUES
('\\longrightarrow','\\longrightarrow','gerichteter Entwicklungspfeil',
 'Kennzeichnet in den schematischen Gleichungen eine logisch oder funktional gerichtete Entwicklungsfolge.',
 'global',(SELECT section_id FROM dissertation_sections WHERE section_code='3.1.5'),'checked',
 (SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'));

-- Initial definitions already explicitly present in the existing chapter logic
INSERT INTO definitions
(definition_number,section_id,title,definition_text,formal_latex,word_latex,provenance,source_id,
 validation_status,created_revision_id)
VALUES
('Def. 3.1.1',
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.1.3'),
 'Funktionale Theorie von Raum und Zeit',
 'Eine funktionale Theorie von Raum und Zeit führt Raum und Zeit nicht als primitive Begriffe ein, sondern verlangt ihre Herleitung aus allgemeineren funktionalen Prinzipien.',
 NULL,NULL,'original',NULL,'checked',
 (SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'));

-- Initial figures and tables are registered as planned repository objects.
INSERT INTO figures
(figure_number,section_id,title,caption,figure_type,provenance,validation_status,created_revision_id)
VALUES
('Abb. 3.P1',
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.4'),
 'Geplante Übersicht der funktionalen Entwicklungsfolge',
 'Geplante schematische Darstellung der Entwicklung von funktionalen Axiomen über Rekursion und Kohärenz zu Raum und Zeit.',
 'schema','original','draft',
 (SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'));

INSERT INTO dissertation_tables
(table_number,section_id,title,caption,table_schema_json,table_data_json,provenance,validation_status,created_revision_id)
VALUES
('Tab. 3.P1',
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.4'),
 'Geplantes Gleichungskataster Kapitel 3',
 'Geplante Zusammenstellung aller Gleichungen aus Kapitel 3 mit Textstelle, Nummer, Word-LaTeX und Herkunft.',
 JSON_OBJECT('columns',JSON_ARRAY('Textstelle','Gleichungsnummer','Word-LaTeX','Herkunft')),
 JSON_ARRAY(),
 'original','draft',
 (SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'));

-- Initial equation dependency: equation 3.2 contrasts equation 3.1
INSERT INTO equation_dependencies
(equation_id,depends_on_equation_id,dependency_type,dependency_note)
VALUES
((SELECT equation_id FROM equations WHERE equation_number='3.2'),
 (SELECT equation_id FROM equations WHERE equation_number='3.1'),
 'contrasts',
 'Die FRZK-Entwicklungsrichtung wird der klassischen Entwicklungsrichtung gegenübergestellt.');

-- Initial change-log entries
INSERT INTO section_change_log
(revision_id,section_id,change_type,object_type,object_reference,change_summary)
VALUES
((SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'),
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.1'),
 'acronym_added','acronym','FRZK','FRZK in das globale Abkürzungsverzeichnis aufgenommen.'),
((SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'),
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.1.3'),
 'definition_added','definition','Def. 3.1.1','Erste repositoryweite Definition registriert.'),
((SELECT revision_id FROM repository_revisions WHERE revision_code='RKB-2026-07-11-V2'),
 (SELECT section_id FROM dissertation_sections WHERE section_code='3.1.5'),
 'symbol_added','symbol','\\longrightarrow','Gerichteten Entwicklungspfeil in das Symbolverzeichnis aufgenommen.');
