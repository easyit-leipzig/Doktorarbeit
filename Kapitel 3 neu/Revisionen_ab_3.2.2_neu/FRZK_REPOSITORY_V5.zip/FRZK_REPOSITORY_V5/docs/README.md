# FRZK Repository V5

## Zweck
Dieses Paket vereinheitlicht die Repository-Revisionen 3.2.1 bis 3.2.6. Die Migrationen sind idempotent und können nach einem Fehler vollständig erneut ausgeführt werden.

## Welche Master-Datei verwenden?

### phpMyAdmin oder Adminer
Importiere **`MASTER_3_2_COMBINED.sql`**. Diese Datei enthält alle sechs Migrationen und den Abschlussaudit in einer Datei.

### MySQL-/MariaDB-Kommandozeile
Starte im entpackten Hauptverzeichnis:

```bash
mysql -u USER -p frzk_rkb < MASTER_BUILD_CLI.sql
```

Die CLI-Variante verwendet `SOURCE` und lädt zusätzlich die zentrale Prozedurbibliothek.

## Einzelmigrationen
Die Dateien liegen unter `02_chapter_3_2/migrations/` und sind in folgender Reihenfolge auszuführen:

1. `3_2_1_V5.sql`
2. `3_2_2_V5.sql`
3. `3_2_3_V5.sql`
4. `3_2_4_V5.sql`
5. `3_2_5_V5.sql`
6. `3_2_6_V5.sql`

## Audit
`audit/MASTER_AUDIT_3_2.sql` kontrolliert Revisionen, Abschnittsstatus, Gleichungsnummern, Word-LaTeX, doppelte Gleichungen, doppelte Gleichungssymbole, Waisen, Quellenziffern und Repository-Zähler.

Erwarteter Endstand:

- letzter Abschnitt: `3.2.6`
- nächste Quellenziffer: `70`
- nächste Gleichung: `3.159`

## Rollback
`rollback/ROLLBACK_3_2_1_TO_3_2_6.sql` entfernt die inhaltlichen Artefakte 3.2.1–3.2.6 und setzt die Abschnittsgerüste auf `planned`. Neue Quellen [58]–[69] werden nur gelöscht, wenn sie anschließend nirgends mehr verwendet werden.

Vor einem Rollback immer eine Datenbanksicherung erstellen.

## Zentrale Prozeduren
`00_infrastructure/010_repository_procedures.sql` stellt Hilfsprozeduren für künftige Abschnitte bereit:

- `repo_begin_revision`
- `repo_set_counter`
- `repo_upsert_equation_symbol`
- `repo_assert_section_exists`

Die vorhandenen V5-Migrationen bleiben eigenständig ausführbar; neue Abschnitte ab 3.2.7 können schrittweise auf die Prozedurbibliothek umgestellt werden.
