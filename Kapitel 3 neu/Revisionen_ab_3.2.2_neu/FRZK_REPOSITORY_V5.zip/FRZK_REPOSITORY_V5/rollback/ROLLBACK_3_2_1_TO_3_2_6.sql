USE `frzk_rkb`;
SET NAMES utf8mb4;
START TRANSACTION;

DROP TEMPORARY TABLE IF EXISTS tmp_rollback_sections;
CREATE TEMPORARY TABLE tmp_rollback_sections (`section_id` BIGINT UNSIGNED PRIMARY KEY);
INSERT INTO tmp_rollback_sections
SELECT section_id FROM dissertation_sections
WHERE section_code IN ('3.2.1','3.2.2','3.2.3','3.2.4','3.2.5','3.2.6');

DROP TEMPORARY TABLE IF EXISTS tmp_rollback_equations;
CREATE TEMPORARY TABLE tmp_rollback_equations (`equation_id` BIGINT UNSIGNED PRIMARY KEY);
INSERT INTO tmp_rollback_equations
SELECT equation_id FROM equations WHERE section_id IN (SELECT section_id FROM tmp_rollback_sections);

DELETE FROM equation_dependencies
WHERE equation_id IN (SELECT equation_id FROM tmp_rollback_equations)
   OR depends_on_equation_id IN (SELECT equation_id FROM tmp_rollback_equations);
DELETE FROM equation_symbols WHERE equation_id IN (SELECT equation_id FROM tmp_rollback_equations);
DELETE FROM equations WHERE equation_id IN (SELECT equation_id FROM tmp_rollback_equations);
DELETE FROM definitions WHERE section_id IN (SELECT section_id FROM tmp_rollback_sections);
DELETE FROM source_usage WHERE section_id IN (SELECT section_id FROM tmp_rollback_sections);
DELETE FROM symbols WHERE first_section_id IN (SELECT section_id FROM tmp_rollback_sections) AND scope_type='section';

DELETE scl FROM section_change_log scl
JOIN repository_revisions rr ON rr.revision_id=scl.revision_id
WHERE rr.scope_reference IN ('3.2.1','3.2.2','3.2.3','3.2.4','3.2.5','3.2.6')
  AND rr.version_label IN ('2.0','4.0','5.0');

DELETE FROM repository_revisions
WHERE scope_reference IN ('3.2.1','3.2.2','3.2.3','3.2.4','3.2.5','3.2.6')
  AND version_label IN ('2.0','4.0','5.0');

UPDATE dissertation_sections
SET status='planned',updated_at=NOW(),
    notes='Durch kontrolliertes V5-Rollback auf Abschnittsgerüst zurückgesetzt.'
WHERE section_id IN (SELECT section_id FROM tmp_rollback_sections);

/* Nur neu eingeführte Quellen löschen, wenn keine andere Verwendung mehr existiert. */
DELETE sa FROM source_authors sa
JOIN sources s ON s.source_id=sa.source_id
LEFT JOIN source_usage su ON su.source_id=s.source_id
WHERE s.citation_number BETWEEN 58 AND 69
GROUP BY sa.source_id,sa.author_id,sa.author_order,sa.role
HAVING COUNT(su.source_id)=0;

DELETE an FROM annotations an
JOIN sources s ON s.source_id=an.source_id
LEFT JOIN source_usage su ON su.source_id=s.source_id
WHERE s.citation_number BETWEEN 58 AND 69
GROUP BY an.annotation_id
HAVING COUNT(su.source_id)=0;

DELETE s FROM sources s
LEFT JOIN source_usage su ON su.source_id=s.source_id
WHERE s.citation_number BETWEEN 58 AND 69
  AND su.source_id IS NULL;

INSERT INTO repository_counters(counter_key,counter_value) VALUES
('last_edited_section','3.2.0'),
('next_citation_number','58'),
('next_equation_number','3.3'),
('last_repository_revision','RKB-2026-07-12-K3.2.0-NEUFASSUNG-V1')
ON DUPLICATE KEY UPDATE counter_value=VALUES(counter_value);

COMMIT;
