-- FRZK Research Knowledge Base
-- Repository extension v2.0
-- Extends the existing frzk_rkb schema into a complete dissertation repository.
-- MySQL 8.0+

USE frzk_rkb;
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP VIEW IF EXISTS v_section_inventory;
DROP VIEW IF EXISTS v_acronym_register;
DROP VIEW IF EXISTS v_symbol_register;
DROP VIEW IF EXISTS v_table_register;
DROP VIEW IF EXISTS v_figure_register;
DROP VIEW IF EXISTS v_statement_register;
DROP VIEW IF EXISTS v_definition_register;
DROP VIEW IF EXISTS v_pending_source_audit;

CREATE TABLE IF NOT EXISTS pending_sources (
    pending_source_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    proposed_source_key VARCHAR(150),
    title VARCHAR(1000) NOT NULL,
    authors_text VARCHAR(1000),
    year_text VARCHAR(50),
    publication_text VARCHAR(1000),
    doi_or_url VARCHAR(1500),
    proposed_section_code VARCHAR(50),
    discovery_context TEXT NOT NULL,
    proposed_claim TEXT,
    priority TINYINT UNSIGNED NOT NULL DEFAULT 3,
    review_status ENUM('open','in_review','accepted','rejected','merged') NOT NULL DEFAULT 'open',
    merged_source_id BIGINT UNSIGNED NULL,
    discovered_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    reviewed_at DATETIME,
    review_notes TEXT,
    KEY idx_pending_status (review_status),
    KEY idx_pending_section (proposed_section_code),
    CONSTRAINT fk_pending_merged_source
        FOREIGN KEY (merged_source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS repository_revisions (
    revision_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    revision_code VARCHAR(100) NOT NULL,
    revision_date DATETIME NOT NULL,
    scope_type ENUM('repository','chapter','section','source','equation','definition','statement','figure','table','symbol','acronym') NOT NULL,
    scope_reference VARCHAR(255),
    version_label VARCHAR(100) NOT NULL,
    summary TEXT NOT NULL,
    created_by VARCHAR(255) DEFAULT 'Olaf Thiele / ChatGPT',
    parent_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_revision_code (revision_code),
    CONSTRAINT fk_revision_parent
        FOREIGN KEY (parent_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS section_change_log (
    change_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    revision_id BIGINT UNSIGNED NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    change_type ENUM(
        'created','rewritten','edited','renumbered','source_added','source_reused',
        'equation_added','equation_changed','definition_added','statement_added',
        'figure_added','table_added','symbol_added','acronym_added','status_changed','other'
    ) NOT NULL,
    object_type VARCHAR(100),
    object_reference VARCHAR(255),
    change_summary TEXT NOT NULL,
    previous_value LONGTEXT,
    new_value LONGTEXT,
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_change_section (section_id),
    KEY idx_change_revision (revision_id),
    CONSTRAINT fk_change_revision
        FOREIGN KEY (revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_change_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS definitions (
    definition_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    definition_number VARCHAR(50) NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    definition_text LONGTEXT NOT NULL,
    formal_latex LONGTEXT,
    word_latex LONGTEXT,
    provenance ENUM('original','adapted','literature') NOT NULL DEFAULT 'original',
    source_id BIGINT UNSIGNED NULL,
    assumptions TEXT,
    notes TEXT,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_definition_number (definition_number),
    KEY idx_definition_section (section_id),
    CONSTRAINT fk_definitions_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_definitions_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_definitions_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS theorems (
    theorem_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    theorem_number VARCHAR(50) NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    statement_text LONGTEXT NOT NULL,
    statement_latex LONGTEXT,
    word_latex LONGTEXT,
    proof_text LONGTEXT,
    provenance ENUM('original','adapted','literature') NOT NULL DEFAULT 'literature',
    source_id BIGINT UNSIGNED NULL,
    assumptions TEXT,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_theorem_number (theorem_number),
    CONSTRAINT fk_theorems_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_theorems_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_theorems_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS lemmas (
    lemma_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    lemma_number VARCHAR(50) NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    statement_text LONGTEXT NOT NULL,
    statement_latex LONGTEXT,
    word_latex LONGTEXT,
    proof_text LONGTEXT,
    provenance ENUM('original','adapted','literature') NOT NULL DEFAULT 'literature',
    source_id BIGINT UNSIGNED NULL,
    assumptions TEXT,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_lemma_number (lemma_number),
    CONSTRAINT fk_lemmas_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_lemmas_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_lemmas_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS corollaries (
    corollary_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    corollary_number VARCHAR(50) NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    statement_text LONGTEXT NOT NULL,
    statement_latex LONGTEXT,
    word_latex LONGTEXT,
    derivation_text LONGTEXT,
    parent_theorem_id BIGINT UNSIGNED NULL,
    parent_lemma_id BIGINT UNSIGNED NULL,
    provenance ENUM('original','adapted','literature') NOT NULL DEFAULT 'literature',
    source_id BIGINT UNSIGNED NULL,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_corollary_number (corollary_number),
    CONSTRAINT fk_corollaries_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_corollaries_theorem
        FOREIGN KEY (parent_theorem_id) REFERENCES theorems(theorem_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_corollaries_lemma
        FOREIGN KEY (parent_lemma_id) REFERENCES lemmas(lemma_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_corollaries_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_corollaries_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS figures (
    figure_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    figure_number VARCHAR(50) NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    caption LONGTEXT NOT NULL,
    file_name VARCHAR(500),
    file_path VARCHAR(1500),
    alt_text LONGTEXT,
    figure_type ENUM('diagram','plot','photograph','schema','flowchart','network','other') NOT NULL DEFAULT 'other',
    provenance ENUM('original','adapted','literature') NOT NULL DEFAULT 'original',
    source_id BIGINT UNSIGNED NULL,
    generation_method TEXT,
    data_reference TEXT,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_figure_number (figure_number),
    CONSTRAINT fk_figures_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_figures_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_figures_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS dissertation_tables (
    table_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    table_number VARCHAR(50) NOT NULL,
    section_id BIGINT UNSIGNED NOT NULL,
    title VARCHAR(500) NOT NULL,
    caption LONGTEXT,
    table_schema_json JSON,
    table_data_json JSON,
    file_name VARCHAR(500),
    file_path VARCHAR(1500),
    provenance ENUM('original','adapted','literature') NOT NULL DEFAULT 'original',
    source_id BIGINT UNSIGNED NULL,
    generation_method TEXT,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_table_number (table_number),
    CONSTRAINT fk_tables_section
        FOREIGN KEY (section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT fk_tables_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_tables_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS symbols (
    symbol_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    symbol_latex VARCHAR(255) NOT NULL,
    symbol_word_latex VARCHAR(255) NOT NULL,
    symbol_name VARCHAR(255) NOT NULL,
    definition_text LONGTEXT NOT NULL,
    scope_type ENUM('global','chapter','section','equation') NOT NULL DEFAULT 'global',
    first_section_id BIGINT UNSIGNED NULL,
    first_equation_id BIGINT UNSIGNED NULL,
    unit_text VARCHAR(255),
    domain_text VARCHAR(1000),
    codomain_text VARCHAR(1000),
    is_vector BOOLEAN NOT NULL DEFAULT FALSE,
    is_matrix BOOLEAN NOT NULL DEFAULT FALSE,
    is_operator BOOLEAN NOT NULL DEFAULT FALSE,
    notes TEXT,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_symbol_scope (symbol_latex, scope_type, first_section_id),
    CONSTRAINT fk_symbols_section
        FOREIGN KEY (first_section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_symbols_equation
        FOREIGN KEY (first_equation_id) REFERENCES equations(equation_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_symbols_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS acronyms (
    acronym_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    acronym VARCHAR(100) NOT NULL,
    full_form VARCHAR(1000) NOT NULL,
    explanation LONGTEXT,
    first_section_id BIGINT UNSIGNED NULL,
    language_code CHAR(2) NOT NULL DEFAULT 'de',
    category VARCHAR(255),
    is_project_specific BOOLEAN NOT NULL DEFAULT FALSE,
    validation_status ENUM('draft','checked','verified') NOT NULL DEFAULT 'draft',
    created_revision_id BIGINT UNSIGNED NULL,
    UNIQUE KEY uq_acronym (acronym),
    CONSTRAINT fk_acronyms_section
        FOREIGN KEY (first_section_id) REFERENCES dissertation_sections(section_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_acronyms_revision
        FOREIGN KEY (created_revision_id) REFERENCES repository_revisions(revision_id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS equation_dependencies (
    dependency_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    equation_id BIGINT UNSIGNED NOT NULL,
    depends_on_equation_id BIGINT UNSIGNED NOT NULL,
    dependency_type ENUM('derived_from','uses','special_case_of','generalizes','validates','contrasts') NOT NULL,
    dependency_note TEXT,
    UNIQUE KEY uq_equation_dependency (equation_id, depends_on_equation_id, dependency_type),
    CONSTRAINT fk_equation_dependencies_equation
        FOREIGN KEY (equation_id) REFERENCES equations(equation_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_equation_dependencies_parent
        FOREIGN KEY (depends_on_equation_id) REFERENCES equations(equation_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS object_source_links (
    object_source_link_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    object_type ENUM('definition','theorem','lemma','corollary','equation','figure','table','symbol','acronym') NOT NULL,
    object_id BIGINT UNSIGNED NOT NULL,
    source_id BIGINT UNSIGNED NOT NULL,
    usage_type ENUM('primary_source','supporting_source','adapted_from','contrasts','historical_context','verification') NOT NULL,
    note TEXT,
    UNIQUE KEY uq_object_source (object_type, object_id, source_id, usage_type),
    CONSTRAINT fk_object_source_source
        FOREIGN KEY (source_id) REFERENCES sources(source_id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE VIEW v_pending_source_audit AS
SELECT
    pending_source_id,
    proposed_source_key,
    title,
    authors_text,
    proposed_section_code,
    priority,
    review_status,
    discovered_at,
    reviewed_at
FROM pending_sources
ORDER BY FIELD(review_status,'open','in_review','accepted','merged','rejected'), priority DESC, discovered_at;

CREATE VIEW v_definition_register AS
SELECT
    d.definition_number,
    ds.section_code,
    ds.title AS section_title,
    d.title,
    d.definition_text,
    d.word_latex,
    d.provenance,
    s.citation_number AS source_citation_number,
    d.validation_status
FROM definitions d
JOIN dissertation_sections ds ON ds.section_id = d.section_id
LEFT JOIN sources s ON s.source_id = d.source_id
ORDER BY d.definition_number;

CREATE VIEW v_statement_register AS
SELECT 'theorem' AS statement_type, t.theorem_number AS statement_number,
       ds.section_code, t.title, t.statement_text, t.word_latex,
       t.provenance, s.citation_number AS source_citation_number, t.validation_status
FROM theorems t
JOIN dissertation_sections ds ON ds.section_id=t.section_id
LEFT JOIN sources s ON s.source_id=t.source_id
UNION ALL
SELECT 'lemma', l.lemma_number, ds.section_code, l.title, l.statement_text, l.word_latex,
       l.provenance, s.citation_number, l.validation_status
FROM lemmas l
JOIN dissertation_sections ds ON ds.section_id=l.section_id
LEFT JOIN sources s ON s.source_id=l.source_id
UNION ALL
SELECT 'corollary', c.corollary_number, ds.section_code, c.title, c.statement_text, c.word_latex,
       c.provenance, s.citation_number, c.validation_status
FROM corollaries c
JOIN dissertation_sections ds ON ds.section_id=c.section_id
LEFT JOIN sources s ON s.source_id=c.source_id;

CREATE VIEW v_figure_register AS
SELECT f.figure_number, ds.section_code, f.title, f.caption, f.file_name, f.file_path,
       f.provenance, s.citation_number AS source_citation_number, f.validation_status
FROM figures f
JOIN dissertation_sections ds ON ds.section_id=f.section_id
LEFT JOIN sources s ON s.source_id=f.source_id
ORDER BY f.figure_number;

CREATE VIEW v_table_register AS
SELECT t.table_number, ds.section_code, t.title, t.caption, t.file_name, t.file_path,
       t.provenance, s.citation_number AS source_citation_number, t.validation_status
FROM dissertation_tables t
JOIN dissertation_sections ds ON ds.section_id=t.section_id
LEFT JOIN sources s ON s.source_id=t.source_id
ORDER BY t.table_number;

CREATE VIEW v_symbol_register AS
SELECT s.symbol_latex, s.symbol_word_latex, s.symbol_name, s.definition_text,
       s.scope_type, ds.section_code AS first_section_code, e.equation_number AS first_equation_number,
       s.unit_text, s.domain_text, s.codomain_text, s.validation_status
FROM symbols s
LEFT JOIN dissertation_sections ds ON ds.section_id=s.first_section_id
LEFT JOIN equations e ON e.equation_id=s.first_equation_id
ORDER BY s.symbol_name, s.symbol_latex;

CREATE VIEW v_acronym_register AS
SELECT a.acronym, a.full_form, a.explanation, ds.section_code AS first_section_code,
       a.category, a.is_project_specific, a.validation_status
FROM acronyms a
LEFT JOIN dissertation_sections ds ON ds.section_id=a.first_section_id
ORDER BY a.acronym;

CREATE VIEW v_section_inventory AS
SELECT
    ds.section_code,
    ds.title,
    ds.status,
    COUNT(DISTINCT su.source_id) AS source_count,
    COUNT(DISTINCT e.equation_id) AS equation_count,
    COUNT(DISTINCT d.definition_id) AS definition_count,
    COUNT(DISTINCT th.theorem_id) AS theorem_count,
    COUNT(DISTINCT l.lemma_id) AS lemma_count,
    COUNT(DISTINCT c.corollary_id) AS corollary_count,
    COUNT(DISTINCT f.figure_id) AS figure_count,
    COUNT(DISTINCT dt.table_id) AS table_count
FROM dissertation_sections ds
LEFT JOIN source_usage su ON su.section_id=ds.section_id
LEFT JOIN equations e ON e.section_id=ds.section_id
LEFT JOIN definitions d ON d.section_id=ds.section_id
LEFT JOIN theorems th ON th.section_id=ds.section_id
LEFT JOIN lemmas l ON l.section_id=ds.section_id
LEFT JOIN corollaries c ON c.section_id=ds.section_id
LEFT JOIN figures f ON f.section_id=ds.section_id
LEFT JOIN dissertation_tables dt ON dt.section_id=ds.section_id
GROUP BY ds.section_id, ds.section_code, ds.title, ds.status
ORDER BY ds.section_order;

SET FOREIGN_KEY_CHECKS = 1;
